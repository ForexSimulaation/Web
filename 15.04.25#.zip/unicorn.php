<?PHP
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Unicorns and the Golden Number</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #ff9a9e, #fad0c4, #fbc2eb);
            color: #333;
            text-align: center;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: #ffdfba;
            padding: 20px;
            border-bottom: 5px solid #ffb7c5;
        }
        header h1 {
            margin: 0;
            color: #d355e7;
        }
        section {
            margin: 20px auto;
            max-width: 800px;
            padding: 20px;
            background: #ffffff80;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        h2 {
            color: #a44edd;
        }
        p {
            font-size: 1.2em;
            line-height: 1.6;
        }
        footer {
            background-color: #ffb7c5;
            padding: 10px;
            position: fixed;
            width: 100%;
            bottom: 0;
            color: #fff;
            font-weight: bold;
        }
        .golden-number {
            font-size: 2em;
            color: #ffbf00;
        }
    </style>
</head>
<body>
    <header>
        <h1>Unicorns and the Golden Number</h1>
    </header>
    <section>
        <h2>The Magic of Unicorns</h2>
        <p>
            Unicorns have captivated our imaginations for centuries. These mythical creatures symbolize purity, magic, and infinite possibilities. 
            They are said to gallop over rainbows and live in lush enchanted forests. Their horns are believed to possess healing powers, and their 
            presence brings happiness and wonder.
        </p>
        <h2>The Enigma of the Golden Number</h2>
        <p>
            The <span class="golden-number">Golden Number</span>, also known as Phi (Φ ≈ 1.618), is a mystical mathematical ratio that appears 
            everywhere in nature, art, and even architecture. From the spirals of seashells to the patterns of galaxies, the Golden Number has 
            fascinated humans for ages.
        </p>
        <p>
            Some believe that unicorns, with their magical horns, hold a deep connection to the Golden Number, embodying its harmony and perfection. 
            Could this be why their beauty is so enchanting?
        </p>
    </section>
    <footer>
        Unicorns + Golden Number = Pure Magic ✨
    </footer>
</body>
</html>
