<?php
require 'fetch.config.php';

// Fetch Forex Data (Example using Alpha Vantage API)
function getForexData($pair) {
  $apiKey = 'MQ9UJN1LOAKQDMFX';
  $url = "https://www.alphavantage.co/query?function=CURRENCY_EXCHANGE_RATE&from_currency=" . 
          substr($pair, 0, 3) . "&to_currency=" . substr($pair, 4, 3) . "&apikey=$apiKey";
  $data = json_decode(file_get_contents($url), true);
  return $data['Realtime Currency Exchange Rate']['5. Exchange Rate'];
}

// Generate Message Content
function createMessage($pair, $rate) {
  $analysis = "Latest $pair Analysis:\n";
  $analysis .= "- Current Rate: $rate\n";
  $analysis .= "- Key Levels: Support at 1.0800, Resistance at 1.0900\n";
  $analysis .= "- Recommendation: Buy on pullbacks.\n";
  return $analysis;
}

// Send Message to Subscribed Users
$eurusdRate = getForexData('EUR/USD');
$messageContent = createMessage('EUR/USD', $eurusdRate);

// Get users subscribed to EUR/USD
$stmt = $pdo->prepare("SELECT id FROM users WHERE JSON_CONTAINS(subscribed_pairs, '[\"EUR/USD\"]')");
$stmt->execute();
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Insert messages
foreach ($users as $user) {
  $stmt = $pdo->prepare("INSERT INTO messages (user_id, sender, subject, content) 
                         VALUES (?, 'ForexAutonomy', 'Market Update #1', ?)");
  $stmt->execute([$user['id'], $messageContent]);
}

echo "Messages sent!";
?>