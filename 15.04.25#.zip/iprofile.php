<?php
// profile.php
$page_title = "ForexTwo's Profile";
$active_tab = "profile"; // can be 'profile' or 'security'
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title ?></title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="bg-dark text-white font-inter">
    <!-- Main Container -->
    <div class="container mx-auto px-4 py-8">
        <!-- Profile Header -->
        <div class="flex justify-between items-center mb-8">
            <h1 class="text-3xl font-bold">Account Settings</h1>
            <a href="/logout" class="bg-primary hover:bg-opacity-90 px-6 py-2 rounded-lg transition">Logout</a>
        </div>

        <!-- Main Content Grid -->
        <div class="lg:flex gap-8">
            <!-- Sidebar Navigation -->
            <nav class="lg:w-1/4 mb-8 lg:mb-0">
                <div class="bg-black p-6 rounded-lg shadow-lg">
                    <ul class="space-y-3">
                        <li>
                            <a href="#profile" class="flex items-center px-4 py-3 <?= $active_tab === 'profile' ? 'bg-primary bg-opacity-20' : 'hover:bg-opacity-10' ?> rounded-lg transition">
                                <span class="mr-3">👤</span> Profile
                            </a>
                        </li>
                        <li>
                            <a href="#security" class="flex items-center px-4 py-3 <?= $active_tab === 'security' ? 'bg-primary bg-opacity-20' : 'hover:bg-opacity-10' ?> rounded-lg transition">
                                <span class="mr-3">🔒</span> Security
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <!-- Profile Content -->
            <main class="lg:w-3/4">
                <!-- Profile Section -->
                <div class="bg-black p-8 rounded-lg shadow-lg">
                    <form>
                        <!-- Form Grid -->
                        <div class="grid md:grid-cols-2 gap-6">
                            <!-- First Name -->
                            <div>
                                <label class="block text-body-color mb-2">First Name</label>
                                <input type="text" value="Mendallon" 
                                    class="w-full bg-dark border border-body-color border-opacity-25 rounded-lg px-4 py-3 focus:ring-2 focus:ring-primary">
                            </div>
                            
                            <!-- Last Name -->
                            <div>
                                <label class="block text-body-color mb-2">Last Name</label>
                                <input type="text" value="Autonomy" 
                                    class="w-full bg-dark border border-body-color border-opacity-25 rounded-lg px-4 py-3 focus:ring-2 focus:ring-primary">
                            </div>

                            <!-- Email -->
                            <div class="md:col-span-2">
                                <label class="block text-body-color mb-2">Email</label>
                                <input type="email" value="forexautonomy@gmail.com" disabled
                                    class="w-full bg-dark border border-body-color border-opacity-25 rounded-lg px-4 py-3 opacity-70 cursor-not-allowed">
                            </div>

                            <!-- Phone -->
                            <div class="md:col-span-2">
                                <label class="block text-body-color mb-2">Phone</label>
                                <input type="tel" value="+1 - 803 - 453" 
                                    class="w-full bg-dark border border-body-color border-opacity-25 rounded-lg px-4 py-3 focus:ring-2 focus:ring-primary">
                            </div>
                        </div>

                        <!-- Save Button -->
                        <div class="mt-8 border-t border-body-color border-opacity-10 pt-6">
                            <button type="submit" 
                                class="bg-primary hover:bg-opacity-90 px-8 py-3 rounded-lg transition float-right">
                                Save Changes
                            </button>
                        </div>
                    </form>
                </div>
            </main>
        </div>

        <!-- Footer -->
        <footer class="mt-12 pt-8 border-t border-body-color border-opacity-10">
            <div class="grid md:grid-cols-4 gap-8 text-body-color">
                <div>
                    <h4 class="text-white mb-4">Trading</h4>
                    <ul class="space-y-2">
                        <li><a href="#" class="hover:text-primary transition">My Plans</a></li>
                        <li><a href="#" class="hover:text-primary transition">Algorithms</a></li>
                    </ul>
                </div>
                
                <div>
                    <h4 class="text-white mb-4">Support</h4>
                    <ul class="space-y-2">
                        <li><a href="#" class="hover:text-primary transition">Open Ticket</a></li>
                        <li><a href="#" class="hover:text-primary transition">EA Development</a></li>
                    </ul>
                </div>
                
                <!-- Add other footer columns similarly -->
            </div>
            
            <div class="mt-8 text-center text-body-color">
                <p>©2025 Forex Autonomy</p>
            </div>
        </footer>
    </div>
</body>
</html>