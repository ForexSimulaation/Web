<?php
// Standalone Simulation
$google_oauth_redirect_uri = 'https://www.forexautonomy.com/autenticate/oauth2.php';
// Render google login button
	$GUI = '<a href="'.filter_var($google_oauth_redirect_uri, FILTER_SANITIZE_URL).'" class="login-btn">Sign in with Google</a>';
$hack = substr($_SERVER["SCRIPT_NAME"],strrpos($_SERVER["SCRIPT_NAME"],"/")+1);
if ($hack == "index.php") echo "<script>window.top.location='http://www.forexautonomy.com/404'</script>";

?>
<!DOCTYPE html>
<html lang="en-US">
<head>
<title>Login with Google using PHP</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- Stylesheet file -->
<link rel="stylesheet" href="css/autentication.css"/>
</head>
<body>
<div class="container">
	<div class="wrapper">
		<!-- Display login button / Google profile information -->
		<?php echo $GUI; ?>
	</div>
</div>
</body>
</html>