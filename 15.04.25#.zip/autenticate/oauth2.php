<?php
include("/home/tecvidjt/public_html/var.php");
// Database connection variables
$Host     = 'dal-shared-30';
$Username = 'tecvidjt_l';
$Password = '141PRdS]p]';
$Name     = 'tecvidjt_members';
$Table    = 'Google';
// Attempt to connect to database
try {
    // Connect to the MySQL database using PDO...
    $pdo = new PDO('mysql:host=' . $Host . ';dbname=' . $Name . ';charset=utf8', $Username, $Password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $exception) {
    // Could not connect to the MySQL database, if this error occurs make sure you check your db settings are correct!
    exit('Failed to connect to database!');
}
// Update the following variables
$google_oauth_client_id = '293544379715-g75pkqdljv94j10e8pgmat1hv8tp5gp5.apps.googleusercontent.com';
$google_oauth_client_secret = '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';
$google_oauth_redirect_uri = 'https://www.forexautonomy.com/autenticate/oauth2.php';
$google_oauth_version = 'v3';

// If the captured code param exists and is valid
if (isset($_GET['code']) && !empty($_GET['code'])) {
    // Execute cURL request to retrieve the access token
    $params = [
        'code' => $_GET['code'],
        'client_id' => $google_oauth_client_id,
        'client_secret' => $google_oauth_client_secret,
        'redirect_uri' => $google_oauth_redirect_uri,
        'grant_type' => 'authorization_code'
    ];
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://accounts.google.com/o/oauth2/token');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);
    $response = json_decode($response, true);
    
    // Make sure access token is valid
if (isset($response['access_token']) && !empty($response['access_token'])) {
    // Execute cURL request to retrieve the user info associated with the Google account
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://www.googleapis.com/oauth2/' . $google_oauth_version . '/userinfo');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Authorization: Bearer ' . $response['access_token']]);
    $response = curl_exec($ch);
    curl_close($ch);
    
    // Decode JSON response
    $GData = json_decode($response, true);

    // Ensure profile data exists
    if (isset($GData['email'])) {
        // Capture all possible fields from $GData
        $gpUserData = [
            'oauth_provider' => 'Google',
            'oauth_uid'      => $GData['id'] ?? '',  // Google unique user ID
            'first_name'     => isset($GData['given_name']) ? preg_replace('/[^a-zA-Z0-9]/s', '', $GData['given_name']) : '',
            'last_name'      => isset($GData['family_name']) ? preg_replace('/[^a-zA-Z0-9]/s', '', $GData['family_name']) : '',
            'email'          => $GData['email'],
            'gender'         => $GData['gender'] ?? '', // Gender might not always be provided
            'locale'         => $GData['locale'] ?? '',
            'picture'        => $GData['picture'] ?? '',
            'datecreated'    => date('Y-m-d H:i:s'),  // Set current timestamp for new user
            'datemodified'   => date('Y-m-d H:i:s')   // Update timestamp (same as created for new user)
        ];

        // Check if the account exists in the database
        $stmt = $pdo->prepare('SELECT * FROM ' . $Table . ' WHERE email = ?');
        $stmt->execute([ $gpUserData['email'] ]);
        $googleAccount = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$googleAccount) {
            // Insert new user
            $stmt = $pdo->prepare('INSERT INTO ' . $Table . ' (oauth_provider, oauth_uid, first_name, last_name, email, gender, locale, picture, datecreated, datemodified) 
                                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
            $stmt->execute([
                $gpUserData['oauth_provider'],
                $gpUserData['oauth_uid'],
                $gpUserData['first_name'],
                $gpUserData['last_name'],
                $gpUserData['email'],
                $gpUserData['gender'],
                $gpUserData['locale'],
                $gpUserData['picture'],
                $gpUserData['datecreated'],
                $gpUserData['datemodified']
            ]);
            $id = $pdo->lastInsertId();
        } else {
            // Update existing user data
            $stmt = $pdo->prepare('UPDATE ' . $Table . ' SET oauth_uid = ?, first_name = ?, last_name = ?, gender = ?, locale = ?, picture = ?, datemodified = ? WHERE email = ?');
            $stmt->execute([
                $gpUserData['oauth_uid'],
                $gpUserData['first_name'],
                $gpUserData['last_name'],
                $gpUserData['gender'],
                $gpUserData['locale'],
                $gpUserData['picture'],
                $gpUserData['datemodified'],
                $gpUserData['email']
            ]);
            $id = $googleAccount['id'];
        }

    $_SESSION['googlesignin'] = TRUE;
    //$_SESSION['googlesignin'] = "Autenticate";
    $_SESSION['googleid'] = $id;

    // Redirect to profile page
    header('Location: interface.php');
    exit;
} else {    exit('Could not retrieve profile information! Please try again later!');
}

    } else {
        exit('Invalid access token! Please try again later!');
    }
} else {
    // Define params and redirect to Google Authentication page
    $params = [
        'response_type' => 'code',
        'client_id' => $google_oauth_client_id,
        'redirect_uri' => $google_oauth_redirect_uri,
        'scope' => 'https://www.googleapis.com/auth/userinfo.email https://www.googleapis.com/auth/userinfo.profile',
        'access_type' => 'offline',
        'prompt' => 'consent'
    ];
    header('Location: https://accounts.google.com/o/oauth2/auth?' . http_build_query($params));
    exit;
}
?>