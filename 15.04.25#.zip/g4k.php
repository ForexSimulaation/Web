<?php
//header("Location: /404");

$length = 12;
$lower = md5(uniqid()); $upper = strtoupper($lower); $symbols = '!@$%^&*()'; $charset = $lower.$upper.$symbols; $length = 12;    $charset = md5(uniqid()).'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890!@$%^&*()';

$password = '';
for($i = 0; $i < $length; $i++) {
    $index = rand(0, strlen($charset) - 1);
    $password .= $charset[$index];
}

echo $password;

 
?>