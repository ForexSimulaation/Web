<?php
function Unique() {    date_default_timezone_set('Africa/Lagos');
    $dateTime = new DateTime();    $timestamp = $dateTime->getTimestamp();
    // Define the interval in seconds (48 minutes = 2880 seconds)
    $interval = 48 * 60;    $roundedTimestamp = floor($timestamp / $interval) * $interval;    $dateTime->setTimestamp($roundedTimestamp);$formattedDateTime = $dateTime->format('Y-m-d h:i A');    return md5($formattedDateTime);
}

$server = Unique();
session_id($server);
session_start();
$antihack = substr($_SERVER["SCRIPT_NAME"],strrpos($_SERVER["SCRIPT_NAME"],"/")+1);
if ($antihack == "var.php") echo "<script>window.top.location='http://www.forexautonomy.com/404'</script>";
?>