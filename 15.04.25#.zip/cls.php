<?PHP
include("/home/tecvidjt/public_html/var.php");
include("/home/tecvidjt/public_html/see.php");
require_once("/home/tecvidjt/public_html/linkto/membersite_config.php");
$state = "A0cLU&ifkv=ASKXGp21Nw8OwaHwNR_CJLrqvQcWNBIUTzTlh6HRSZ-Qr1J0YhbokD9076BkWHqSlMHHWkTqc1kmcg";
if($fgmembersite->CheckLogin()) $state = $fgmembersite->UserFullName(); else if (isset($_SESSION['googlesignin'])) $state =  $_SESSION['google_name'];
//'  '
function everyPage ($arg)
{
if($arg=="A0cLU&ifkv=ASKXGp21Nw8OwaHwNR_CJLrqvQcWNBIUTzTlh6HRSZ-Qr1J0YhbokD9076BkWHqSlMHHWkTqc1kmcg") $pagevalue = '<a href="signin" class="hidden md:block text-base font-bold text-dark dark:text-white hover:opacity-70 py-3 px-7"> Sign In </a><a href="signup" class="hidden md:block text-base font-bold text-white bg-primary py-3 px-8 md:px-9 lg:px-6 xl:px-9 hover:shadow-signUp hover:bg-opacity-90 rounded-md transition ease-in-up duration-300"> Sign Up</a>';
else if ($arg!="A0cLU&ifkv=ASKXGp21Nw8OwaHwNR_CJLrqvQcWNBIUTzTlh6HRSZ-Qr1J0YhbokD9076BkWHqSlMHHWkTqc1kmcg") $pagevalue  = '<a href="myprofile" class="hidden md:block text-base font-bold text-dark dark:text-white hover:opacity-70 py-3 px-7"> '.$arg.'</a><a href="logout" class="hidden md:block text-base font-bold text-white bg-primary py-3 px-8 md:px-9 lg:px-6 xl:px-9 hover:shadow-signUp hover:bg-opacity-90 rounded-md transition ease-in-up duration-300">Logout</a>';
return $pagevalue;
}
$hack = substr($_SERVER["SCRIPT_NAME"],strrpos($_SERVER["SCRIPT_NAME"],"/")+1);
if ($hack == "cls.php") echo "<script>window.top.location='http://www.forexautonomy.com/404'</script>";
?>