<?php
$rdata = file_get_contents('php://input');$dlen=strlen($rdata);$rsub=substr($rdata,0,8);$rnt=substr($rdata,8);$rlog=substr($rdata,0,9);$rdt=substr($rdata,9);

$teq=substr($rdata,0,15);$ueq=substr($rdata,15);$rpt=substr($rdata,5);$rch=substr($rdata,0,5);$pwd="Immanuel";$pws="Immanuel*";$rwd="Huynh";$req="Lovski.Immanuel";
$ast = strpos($rpt,'*');$tdata=substr($rpt,0,$ast);$idata=substr($rpt,$ast);$tn=strlen($tdata);$ln=strlen($idata);
$tst = strpos($ueq,'*');$udata=substr($ueq,0,$tst); //echo "Channel - ".$udata."Table Name - ".$teq." Extract  - ".$req;
$servername = 'dal-shared-30';
$username = 'tecvidjt_ex';
$password = '!sUs]ecoqO0W';
$database = 'tecvidjt_3way';

$connection = new mysqli($servername,$username,$password,$database);

if ($rsub==$pwd) {   $sql1 = "CREATE TABLE $rnt (".
                "id_user INT NOT NULL AUTO_INCREMENT ,".
                "threeway  VARCHAR( 8192 ) NOT NULL ,".
                "PRIMARY KEY ( id_user ) ,".
                "date_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP".
                ")";
		if ($connection -> query($sql1)) echo 'Table ', $rnt,' created successfully'; else echo 'Table ', $rnt,' not inputted in database';} 

if ($rlog==$pws) {   $sql0 = "DROP TABLE $rdt ";
		$connection -> query($sql0);} //echo 'Table ', $rdt,' deleted successfully';

if ($rch==$rwd && $tn>0 && $ln>0) {  $sql="INSERT INTO $tdata (threeway) VALUES ('$idata')";  $connection -> query($sql);}

if ($teq==$req)
{//echo "Channel - ".$udata."Table Name - ".$teq." Extract  - ".$req;
$query = "select threeway from $udata order by id_user desc limit 1;";
$queryResult = $connection->query($query);
while ($queryRow = $queryResult->fetch_row()) { echo $queryRow[0];}
}
//---
{if ($dlen<6) header("Location: /live.php"); }
$connection -> close();

?>
