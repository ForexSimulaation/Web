<?PHP

$rawdata = file_get_contents('php://input');

$servername = 'dal-shared-30';
$username = 'tecvidjt_ex';  
$password = '!sUs]ecoqO0W';
$database = 'tecvidjt_pluto';
$t1 = 'B00TradeOne';
$t2 = 'B00TradeTwo';
//---
$connection = new mysqli($servername,$username,$password,$database);
$data_vol=strlen($rawdata);

if ($data_vol>10) {$sqlone="INSERT INTO $t1 (tradeone) VALUES ('$rawdata')";}
//---
$connection -> query($sqlone);

if ($data_vol>10) {$sqltwo="INSERT INTO $t2 (tradetwo) VALUES ('$rawdata')";}
//---
$connection -> query($sqltwo);

{if ($data_vol<8) header("Location: /live"); }
$connection -> close();
//echo 'B00Trade';
?>

