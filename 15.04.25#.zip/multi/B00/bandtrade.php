<?php

$servername = 'dal-shared-30';
$username = 'tecvidjt_ex';  
$password = '!sUs]ecoqO0W';
$database = 'tecvidjt_pluto';
$a = 'B00';

$t1 = $a.'TradeOne';
$t2 = $a.'TradeTwo';
$i1 = $a.'Une';
$i2 = $a.'Deux';


$conn = new mysqli($servername,$username,$password,$database);
{ // sql to create table
  $sql1 = "CREATE TABLE $t1 (".
                "id_user INT NOT NULL AUTO_INCREMENT ,".
                "tradeone VARCHAR( 1000 ) NOT NULL ,".
                "PRIMARY KEY ( id_user ) ,".
                "date_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP".
                ")";
		$conn -> query($sql1);}
echo '/ * /Table ', $t1,' created successfully';
{ // sql to create table
  $sql2 = "CREATE TABLE $t2 (".
                "id_user INT NOT NULL AUTO_INCREMENT ,".
                "tradetwo VARCHAR( 1000 ) NOT NULL ,".
                "PRIMARY KEY ( id_user ) ,".
                "date_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP".
                ")";
		$conn -> query($sql2);}
echo '/ * /Table ', $t2,' created successfully';

{ // sql to create table
  $sqla = "CREATE TABLE $i1 (".
                "id_user INT NOT NULL AUTO_INCREMENT ,".
                "gridone VARCHAR( 1000 ) NOT NULL ,".
                "PRIMARY KEY ( id_user ) ,".
                "date_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP".
                ")";
		$conn -> query($sqla);}
echo '/ # /Table ', $i1,' created successfully';

{ // sql to create table
  $sqlb = "CREATE TABLE $i2 (".
                "id_user INT NOT NULL AUTO_INCREMENT ,".
                "gridtwo VARCHAR( 1000 ) NOT NULL ,".
                "PRIMARY KEY ( id_user ) ,".
                "date_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP".
                ")";
		$conn -> query($sqlb);}
echo '/ # /Table ', $i2,' created successfully';

$conn -> close();

?>