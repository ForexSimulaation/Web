<?php

$servername = 'dal-shared-30';
$username = 'tecvidjt_ex';  
$password = '!sUs]ecoqO0W';
$database = 'tecvidjt_pluto';
$a = 'A00';

$t0 = $a.'Trade';
$t1 = $a.'TradeOne';
$t2 = $a.'TradeTwo';
$t3 = $a.'TradeThree';
$t4 = $a.'TradeFour';
$i1 = $a.'Une';
$i2 = $a.'Deux';
$i3 = $a.'Trois';
$i4 = $a.'Quatre';


$conn = new mysqli($servername,$username,$password,$database);
{ // sql to create table
  $sql0 = "CREATE TABLE $t0 (".
                "id_user INT NOT NULL AUTO_INCREMENT ,".
                "trade VARCHAR( 1000 ) NOT NULL ,".
                "PRIMARY KEY ( id_user ) ,".
                "date_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP".
                ")";
		$conn -> query($sql0);}
echo '/ * /Table ', $t0,' created successfully';
{ // sql to create table
  $sql1 = "CREATE TABLE $t1 (".
                "id_user INT NOT NULL AUTO_INCREMENT ,".
                "tradeone VARCHAR( 1000 ) NOT NULL ,".
                "PRIMARY KEY ( id_user ) ,".
                "date_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP".
                ")";
		$conn -> query($sql1);}
echo '/ * /Table ', $t1,' created successfully';
{ // sql to create table
  $sql2 = "CREATE TABLE $t2 (".
                "id_user INT NOT NULL AUTO_INCREMENT ,".
                "tradetwo VARCHAR( 1000 ) NOT NULL ,".
                "PRIMARY KEY ( id_user ) ,".
                "date_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP".
                ")";
		$conn -> query($sql2);}
echo '/ * /Table ', $t2,' created successfully';
{ // sql to create table
  $sql3 = "CREATE TABLE $t3 (".
                "id_user INT NOT NULL AUTO_INCREMENT ,".
                "tradethree VARCHAR( 1000 ) NOT NULL ,".
                "PRIMARY KEY ( id_user ) ,".
                "date_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP".
                ")";
		$conn -> query($sql3);}
echo '/ * /Table ', $t3,' created successfully';
{ // sql to create table
  $sql4 = "CREATE TABLE $t4 (".
                "id_user INT NOT NULL AUTO_INCREMENT ,".
                "tradefour VARCHAR( 1000 ) NOT NULL ,".
                "PRIMARY KEY ( id_user ) ,".
                "date_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP".
                ")";
		$conn -> query($sql4);}
echo '/ * /Table ', $t4,' created successfully';

//----

{ // sql to create table
  $sqla = "CREATE TABLE $i1 (".
                "id_user INT NOT NULL AUTO_INCREMENT ,".
                "gridone VARCHAR( 1000 ) NOT NULL ,".
                "PRIMARY KEY ( id_user ) ,".
                "date_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP".
                ")";
		$conn -> query($sqla);}
echo '/ # /Table ', $i1,' created successfully';

{ // sql to create table
  $sqlb = "CREATE TABLE $i2 (".
                "id_user INT NOT NULL AUTO_INCREMENT ,".
                "gridtwo VARCHAR( 1000 ) NOT NULL ,".
                "PRIMARY KEY ( id_user ) ,".
                "date_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP".
                ")";
		$conn -> query($sqlb);}
echo '/ # /Table ', $i2,' created successfully';

{ // sql to create table
  $sqlc = "CREATE TABLE $i3 (".
                "id_user INT NOT NULL AUTO_INCREMENT ,".
                "gridthree VARCHAR( 1000 ) NOT NULL ,".
                "PRIMARY KEY ( id_user ) ,".
                "date_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP".
                ")";
		$conn -> query($sqlc);}
echo '/ # /Table ', $i3,' created successfully';

{ // sql to create table
  $sqld = "CREATE TABLE $i4 (".
                "id_user INT NOT NULL AUTO_INCREMENT ,".
                "gridfour VARCHAR( 1000 ) NOT NULL ,".
                "PRIMARY KEY ( id_user ) ,".
                "date_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP".
                ")";
		$conn -> query($sqld);}
echo '/ # /Table ', $i4,' created successfully';

$conn -> close();

?>