<?PHP

$rawdata = file_get_contents('php://input');

$servername = 'dal-shared-30';
$username = 'tecvidjt_ex';  
$password = '!sUs]ecoqO0W';
$database = 'tecvidjt_pluto';
$t0 = 'A00Trade';
$t1 = 'A00TradeOne';
$t2 = 'A00TradeTwo';
$t3 = 'A00TradeThree';
$t4 = 'A00TradeFour';
//---
$connection = new mysqli($servername,$username,$password,$database);
$data_vol=strlen($rawdata);

if ($data_vol>10) {$sqlone="INSERT INTO $t1 (tradeone) VALUES ('$rawdata')";}
//---
$connection -> query($sqlone);

if ($data_vol>10) {$sqltwo="INSERT INTO $t2 (tradetwo) VALUES ('$rawdata')";}
//---
$connection -> query($sqltwo);

if ($data_vol>10) {$sqlthree="INSERT INTO $t3 (tradethree) VALUES ('$rawdata')";}
//---
$connection -> query($sqlthree);

if ($data_vol>10) {$sqlfour="INSERT INTO $t4 (tradefour) VALUES ('$rawdata')";}
//---
$connection -> query($sqlfour);

if ($data_vol>10) {$sql="INSERT INTO $t0 (trade) VALUES ('$rawdata')";}
//---
$connection -> query($sql);

{if ($data_vol<8) header("Location: /live.php"); }
$connection -> close();
//echo 'A00Trade';
?>

