<?php

$rdta = file_get_contents('php://input');$rsb=substr($rdta,0,8);$rinf = ''; if ($rsb == 'Einfach&')$rinf=substr($rdta,8);$ln=strlen($rinf);$la=strlen($rdta);$rkye=substr($rinf,0,1);
$servername = 'dal-shared-30';
$username = 'tecvidjt_ex';  
$password = '!sUs]ecoqO0W';
$database = 'tecvidjt_trv';
$t1 = 'EOLA';

//---
$connection = new mysqli($servername,$username,$password,$database);
if ($ln>12) 
{
$sql="INSERT INTO $t1 (VUTB) VALUES ('$rinf')";

}

$connection -> query($sql);
{if ($la<10) header("Location: /live.php"); }
$connection -> close();

$rdeal= new mysqli($servername, $username, $password, $database);
$qA = "select VUTB from $t1 order by id_user desc limit 1;";$qAR = $rdeal->query($qA);while ($qRA = $qAR->fetch_row()) { $T0 = $qRA[0];}
$rdeal->close();
{if ($rdta=="geom3triz3") echo $T0; }
?>