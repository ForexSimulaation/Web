<?php
function multi($n) {$nd = "#.ssh";  if($n==5) return $nd; if($n==8) return filesize($nd);}
function save($data) {if (strlen($data)>0) {$wfile = fopen(multi(5), "w") or die("Unable to open file!"); fwrite($wfile, $data); fclose($wfile);}}
function read() {$s = multi(8); if ($s>0) {$file = fopen(multi(5), "r") or die("Unable to open file!"); $r = fread($file, $s); fclose($file); return $r;}}
//================================
session_start();
$iori = password_hash($_POST['pass'], PASSWORD_DEFAULT); //save($iori); 
$encrypted = read(); // if(!password_verify($password , $row['password'] ))
//===============================
if(isset($_POST['submit_pass']) && $_POST['pass'])
{
 $pass=$_POST['pass'];
 if(password_verify($pass, $encrypted))
 {
  $_SESSION['access']=$pass;
 }
 else
 {
  $error="Incorrect Access Code";
 }
}

if(isset($_POST['page_logout']))
{
 unset($_SESSION['access']);
}
?>

<html>
<head>
<link rel="stylesheet" type="text/css" href="style/psd.css">
</head>
<body>
<div id="wrapper">

<?php
//echo($_SESSION['access']."***".$encrypted."###".password_hash($pass,PASSWORD_DEFAULT)."!!!".$pass);

//if(password_hash( $_SESSION['access'], PASSWORD_DEFAULT) == $encrypted)
if(password_verify($pass, $encrypted))
{
 ?>

<?php
$servername = 'dal-shared-30';
$username = 'tecvidjt_l';  
$password = '141PRdS]p]';
$database01 = 'tecvidjt_members';
$tablename00 = 'Google';
$tablename01 = 'Enlistee';

//---
$database02 = 'tecvidjt_contact';
$tablename02 = 'KristReception';
$tablename08 = 'KristCore';

//---
$database03 = 'tecvidjt_magazine';//
$tablename03 = 'Periodicals';

//---
$database04 = 'tecvidjt_query';
$tablename04 = 'Book';
//---

?>

<!DOCTYPE html>
<html lang="">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="style/createtab.css">
  <title>Forex Autonomy Members, Subscriptions, amd Comments</title>
</head>
<body>
 <form method="post" class="wrapper" action="" id="logout_form">
  <input type="submit" name="page_logout" value="Access Completed">
 </form>
<p>
</p>
<h2 class="tops">Registred Members, Subscriptions, and Comments </h2>
<?php

$connection00= new mysqli($servername, $username, $password, $database01);
echo "<h5 class='tops'>Connected Successfully</h5>";

$query = "select * from $tablename00 limit 1000;";
$queryResult = $connection00->query($query);
//	id	firstname	lastname	email	username	phone	confirmationcode	password	source	registrationdate	
//id    oauth_provider  oauth_uid  first_name  last_name  email   gender  locale  picture datecreated datemodified

echo "
<p>
</p>
<h3 class='tops'>$tablename00</h3>";
echo "<table border='10px' cellspacing='0' cellpadding='10px'>
    <thead>
      <tr>
        <th>S/N</th>
        <th>OAuth Provider</th>
        <th>OAuth ID</th>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Email</th>
        <th>Gender</th>
        <th>Location</th>
        <th>Avatar URI</th>
        <th>Signup Date</th>
        <th>Last Signin Date</th>
      </tr>      
    </thead>
    <tbody>";
while ($queryRow = $queryResult->fetch_row()) {
    echo "<tr>";
    for($i = 0; $i < $queryResult->field_count; $i++){
        echo "<td>$queryRow[$i]</td>";
    }
    echo "</tr>";
}
echo "</tbody>
    <tfoot>
      <tr>
        <td colspan='11'class='top'>Google Autenticated Forex Autonomy Members</td>
      </tr>
    </tfoot>

  </table>";
$connection00->close();

//-----

$connection01= new mysqli($servername, $username, $password, $database01);
echo "<h5 class='tops'>Connected Successfully</h5>";

$query = "select * from $tablename01 limit 1000;";
$queryResult = $connection01->query($query);
echo "
<p>
</p>
<h3 class='tops'>$tablename01</h3>";
echo "<table border='10px' cellspacing='0' cellpadding='10px'>
    <thead>
      <tr>
        <th>S/N</th>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Username</th>
        <th>Email</th>
        <th>Phone</th>
        <th>ConfirmCode</th>
        <th>Password</th>
        <th>Source</th>
        <th>Signup Date</th>
      </tr>      
    </thead>
    <tbody>";
while ($queryRow = $queryResult->fetch_row()) {
    echo "<tr>";
    for($i = 0; $i < $queryResult->field_count; $i++){
        echo "<td>$queryRow[$i]</td>";
    }
    echo "</tr>";
}
echo "</tbody>
    <tfoot>
      <tr>
        <td colspan='10'class='top'>Forex Autonomy Members</td>
      </tr>
    </tfoot>

  </table>";
$connection01->close();

//-----

$connection02= new mysqli($servername, $username, $password, $database02);
echo "<h5 class='tops'>Connected Successfully</h5>";

$query = "select * from $tablename02 order by id desc limit 5;";
$queryResult = $connection02->query($query);
echo "
<p>
</p>
<h3 class='tops'>$tablename02</h3>";
echo "<table border='10px' cellspacing='0' cellpadding='10px'>
    <thead>
      <tr>
        <th>Id</th>
        <th>Name</th>
        <th>Email</th>
        <th>City</th>
        <th>Country</th>
        <th>Message</th>
        <th>Date Stamp</th>
      </tr>      
    </thead>
    <tbody>";
while ($queryRow = $queryResult->fetch_row()) {
    echo "<tr>";
    for($i = 0; $i < $queryResult->field_count; $i++){
        echo "<td>$queryRow[$i]</td>";
    }
    echo "</tr>";
}
echo "</tbody>
    <tfoot>
      <tr>
        <td colspan='7'class='top'>Contact us, Comments and Feedback</td>
      </tr>
    </tfoot>

  </table>";
$connection02->close();

//-----

$connection08 = new mysqli($servername, $username, $password, $database02);
echo "<h5 class='tops'>Connected Successfully</h5>";

$query = "select * from $tablename08 order by id desc limit 10;";
$queryResult = $connection08->query($query);
echo "
<p>
</p>
<h3 class='tops'>$tablename08</h3>";
echo "<table border='10px' cellspacing='0' cellpadding='10px'>
    <thead>
      <tr>
        <th>Id</th>
        <th>Ticket Category</th>
        <th>Name</th>
        <th>Email</th>
        <th>City</th>
        <th>Country</th>
        <th>Unresolved Issue</th>
        <th>Time Stamp</th>
      </tr>      
    </thead>
    <tbody>";
while ($queryRow = $queryResult->fetch_row()) {
    echo "<tr>";
    for($i = 0; $i < $queryResult->field_count; $i++){
        echo "<td>$queryRow[$i]</td>";
    }
    echo "</tr>";
}
echo "</tbody>
    <tfoot>
      <tr>
        <td colspan='8'class='top'>Support Ticket, Client Complaints and Feedback</td>
      </tr>
    </tfoot>

  </table>";
$connection08->close();

//-----



$connection03= new mysqli($servername, $username, $password, $database03);
echo "<h5 class='tops'>Connected Successfully</h5>";

$query = "select * from $tablename03 limit 1000;";
$queryResult = $connection03->query($query);
echo "
<p>
</p>
<h3 class='tops'>$tablename03</h3>";
echo "<table border='10px' cellspacing='0' cellpadding='10px'>
    <thead>
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Date Stamp</th>
      </tr>      
    </thead>
    <tbody>";
while ($queryRow = $queryResult->fetch_row()) {
    echo "<tr>";
    for($i = 0; $i < $queryResult->field_count; $i++){
        echo "<td>$queryRow[$i]</td>";
    }
    echo "</tr>";
}
echo "</tbody>
    <tfoot>
      <tr>
        <td colspan='7'class='top'>News Letter Subscription</td>
      </tr>
    </tfoot>

  </table>";
$connection03->close();

//-----

$connection04 = new mysqli($servername, $username, $password, $database04);
echo "<h5 class='tops'>Connected Successfully</h5>";

$Scalper = $connection04->query("SELECT automated_trading_assist FROM $tablename04 WHERE automated_trading_assist = 'Scalper Companion'");
$frequencyScalper  =  count($Scalper->fetch_all());
//

$Rainbow = $connection04->query("SELECT automated_trading_assist FROM $tablename04 WHERE automated_trading_assist = 'Rainbow RSI'");
$frequencyRainbow  =  count($Rainbow->fetch_all());
//

$Highs = $connection04->query("SELECT automated_trading_assist FROM $tablename04 WHERE automated_trading_assist = 'Highs & Lows Indicator'");
$frequencyHighs  =  count($Highs->fetch_all());
//

$ZigZag = $connection04->query("SELECT automated_trading_assist FROM $tablename04 WHERE automated_trading_assist = 'ZigZag Pattern Indicator'");
$frequencyZigZag  =  count($ZigZag->fetch_all());
//

$Trendlines = $connection04->query("SELECT automated_trading_assist FROM $tablename04 WHERE automated_trading_assist = 'Major Trendlines Indicator'");
$frequencyTrendlines  =  count($Trendlines->fetch_all());
//

$query = "select * from $tablename04 order by id_user desc limit 10;";
$queryResult = $connection04->query($query);

echo "
<p>
</p>
<h3 class='tops'>Visitors/Downloads</h3>";
echo "<table border='10px' cellspacing='0' cellpadding='10px'>
    <thead>
      <tr>
        <th>ID</th>
        <th>Download</th>
        <th>I.P.</th>
        <th>City</th>
        <th>Region</th>
        <th>Country</th>
        <th>CODE</th>
        <th>Latitude</th>
        <th>Longitude</th>
        <th>Accuracy</th>
        <th>TimeZone</th>
        <th>Currency</th>
        <th>Rate</th>
        <th>User Device</th>
        <th>Date Stamp</th>
      </tr>      
    </thead>
    <tbody>";

while ($queryRow = $queryResult->fetch_row()) {
    echo "<tr>"; 
    for($i = 0; $i < $queryResult->field_count; $i++){
        echo "<td>$queryRow[$i]</td>";
    }

    echo "</tr>";
}
echo "</tbody>
    <tfoot>
      <tr>
        <td colspan='15'class='top'> Number of Download Instances <br>  <br> Scalper Companion = $frequencyScalper <br>  Rainbow RSI = $frequencyRainbow <br>  Highs & Lows Indicator = $frequencyHighs <br>  ZigZag Pattern Indicator = $frequencyZigZag <br>  Major Trendlines Indicator = $frequencyTrendlines <br>  <br> Visitors, Internet Protocol, Location and Time</td>
      </tr>
    </tfoot>

  </table>";
$connection04->close();

//-----

?>

</body>
</html>
 <?php
}
else
{
 ?>
 <form method="post" class="wrapper" action="" id="login_form">
  <h1  class="wrap">Portal</h1>
  <input type="password"  class="wrap" name="pass" placeholder="*******">
  <input type="submit"  class="wrap" name="submit_pass" value="Access">
 <!-- <p><h6>"Enter the right access code"</h6></p> -->
  <p><font style="color:red;"><?php echo $error;?></font></p>
 </form>
 <?php	
}
?>

</div>
</body>
</html>