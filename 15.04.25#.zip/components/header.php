<header class="sticky top-0 z-50 bg-dark bg-opacity-80 backdrop-filter backdrop-blur">
    <nav class="container mx-auto px-4 py-4 flex justify-between items-center">
        <a href="/" class="text-2xl font-bold">ForexTwo</a>
        
        <div class="hidden md:flex space-x-8">
            <a href="messages.php" class="<?= $active_nav === 'messages' ? 'text-primary' : 'text-body-color hover:text-primary' ?> transition">
                Messages <?= $active_nav === 'messages' ? '🔔' : '' ?>
            </a>
            <a href="purchases.php" class="<?= $active_nav === 'purchases' ? 'text-primary' : 'text-body-color hover:text-primary' ?> transition">
                Marketplace
            </a>
            <a href="plans.php" class="<?= $active_nav === 'plans' ? 'text-primary' : 'text-body-color hover:text-primary' ?> transition">
                My Plans
            </a>
        </div>
    </nav>
</header>