<footer class="mt-16 pt-8 border-t border-body-color border-opacity-10">
    <div class="container mx-auto px-4">
        <div class="grid md:grid-cols-4 gap-8 text-body-color">
            <div>
                <h4 class="text-white mb-4">Trading</h4>
                <ul class="space-y-2">
                    <li><a href="#" class="hover:text-primary transition">Plans</a></li>
                    <li><a href="#" class="hover:text-primary transition">Algorithms</a></li>
                </ul>
            </div>
            
            <div>
                <h4 class="text-white mb-4">Support</h4>
                <ul class="space-y-2">
                    <li><a href="#" class="hover:text-primary transition">Documentation</a></li>
                    <li><a href="#" class="hover:text-primary transition">Contact</a></li>
                </ul>
            </div>
            
            <!-- Add more columns as needed -->
        </div>
        
        <div class="mt-8 pt-8 border-t border-body-color border-opacity-10 text-center">
            <p>©2025 Forex Autonomy. All rights reserved.</p>
        </div>
    </div>
</footer>