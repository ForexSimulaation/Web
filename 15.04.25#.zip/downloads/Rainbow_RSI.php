<?php
require('./Plugin.php');
$geoplugin = new geoPlugin();
$geoplugin->locate();
$LocationOfDownloadableFile = "/downloads/Rainbow RSI.ex4";
$DocumentName = "Rainbow RSI";
$ForceFileDownload = "no";
$LocationOfLogFile = "/downloads/Rainbow RSI.txt";
 function getIPaddress() 
 {   if(!empty ($_SERVER['HTTP_CLIENT_IP']))  { $ip = $_SERVER['HTTP_CLIENT_IP'];}  
    elseif (!empty ($_SERVER['HTTP_X_FORWARDED_FOR']))  {$ip = $_SERVER['HTTP_X_FORWARDED_FOR']; }  
    else {$ip = $_SERVER['REMOTE_ADDR']; }  return $ip;  
}  
$acquireip = getIPaddress();//$geo_details = file_get_contents('http://www.geoplugin.net/php.gp?ip='.$acquireip);

$city = $geoplugin->city;
$region = $geoplugin->region;
$countryname = $geoplugin->countryName;
$countrycode = $geoplugin->countryCode;
$latitude = $geoplugin->latitude;
$longitude = $geoplugin->longitude;
$accuracy = $geoplugin->locationAccuracyRadius;
$timezone = $geoplugin->timezone;
$currency = $geoplugin->currencySymbol;
$currencyrate = $geoplugin->currencyConverter;

$user_device_browser = $_SERVER['HTTP_USER_AGENT'];
$servername = 'dal-shared-30';
$username = 'tecvidjt_l';  
$password = '141PRdS]p]';
$database5 = 'tecvidjt_query';
$tablename5 = 'Book';
$connection5 = new mysqli($servername,$username,$password,$database5);

if ($acquireip!='0' ) 
{$sql5 = "INSERT IGNORE INTO $tablename5 (automated_trading_assist,ip,city,region,countryname,countrycode,latitude,longitude,accuracy,timezone,currency,currencyrate,user_device_browser)	
 VALUES ('$DocumentName','$acquireip','$city','$region','$countryname','$countrycode','$latitude','$longitude','$accuracy','$timezone','$currency','$currencyrate','$user_device_browser')"; 
}
if ($connection5 -> query($sql5)) {$search="";}
$connection5 -> close();

file_put_contents("{$_SERVER['DOCUMENT_ROOT']}$LocationOfLogFile",date('r')."\t".$_SERVER['REMOTE_ADDR']."\t$LocationOfDownloadableFile\t".$_SERVER['HTTP_USER_AGENT']."\n",FILE_APPEND);
if( trim(strtolower($ForceFileDownload)) == 'yes' )
{
$filename = array_pop( explode('/',$LocationOfDownloadableFile) );
header('Content-Type:application/octet-stream');
header("Content-Disposition:attachment; filename=\"$filename\"");
readfile("{$_SERVER['DOCUMENT_ROOT']}$LocationOfDownloadableFile");
}
else { header("Location: $LocationOfDownloadableFile"); }
exit;
?>
