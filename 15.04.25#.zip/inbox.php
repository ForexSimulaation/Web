<!DOCTYPE html>
<html>
<head>
  <title>Forex Inbox</title>
  <style>
    .inbox { width: 800px; margin: 20px auto; }
    .message { border: 1px solid #ddd; padding: 15px; margin-bottom: 10px; }
    .unread { background-color: #f0f8ff; font-weight: bold; }
    .sender { color: #666; font-size: 0.9em; }
    .timestamp { color: #999; font-size: 0.8em; }
  </style>
</head>
<body>
  <div class="inbox">
    <h1>Forex Updates</h1>
    <?php
    require 'config.php';
    session_start();
    // Assume user_id is stored in session (for demo: hardcode to 1)
    $userId = 1;

    // Fetch messages
    $stmt = $pdo->prepare("SELECT * FROM messages WHERE user_id = ? ORDER BY created_at DESC");
    $stmt->execute([$userId]);
    $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($messages)) {
      echo "<p>No messages found.</p>";
    } else {
      foreach ($messages as $msg) {
        $unreadClass = $msg['is_read'] ? '' : 'unread';
        echo "<div class='message $unreadClass'>";
        echo "<div class='sender'>From: {$msg['sender']}</div>";
        echo "<h3>{$msg['subject']}</h3>";
        echo "<pre>{$msg['content']}</pre>";
        echo "<div class='timestamp'>{$msg['created_at']}</div>";
        echo "</div>";

        // Mark as read
        if (!$msg['is_read']) {
          $stmt = $pdo->prepare("UPDATE messages SET is_read = 1 WHERE id = ?");
          $stmt->execute([$msg['id']]);
        }
      }
    }
    ?>
  </div>
</body>
</html>