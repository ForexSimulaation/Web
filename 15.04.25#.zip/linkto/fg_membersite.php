<?PHP
/*
    Registration/Login script from HTML Form Guide
    V1.0

    This program is free software published under the
    terms of the GNU Lesser General Public License.
    http://www.gnu.org/copyleft/lesser.html
    

This program is distributed in the hope that it will
be useful - WITHOUT ANY WARRANTY; without even the
implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE.

For updates, please visit:
http://www.html-form-guide.com/php-form/php-registration-form.html
http://www.html-form-guide.com/php-form/php-login-form.html

*/
require_once("/home/tecvidjt/public_html/linkto/class.phpmailer.php");
require_once("/home/tecvidjt/public_html/linkto/formvalidator.php");
require_once("/home/tecvidjt/public_html/linkto/allmessages.php");

class FGMembersite
{
    var $admin_email;
    var $from_address;
    
    var $username;
    var $pwd;
    var $database;
    var $tablename;
    var $connection;
    var $rand_key;
    
    var $error_message;
    
    //-----Initialization -------
    function FGMembersite()
    {
        $this->sitename = 'YourWebsiteName.com';
        $this->rand_key = '0iQx5oBk66oVZep';
    }
    
    function InitDB($host,$uname,$pwd,$database,$tablename)
    {
        $this->db_host  = $host;
        $this->username = $uname;
        $this->pwd  = $pwd;
        $this->database  = $database;
        $this->tablename = $tablename;
        
    }
    function SetAdminEmail($email)
    {
        $this->admin_email = $email;
    }
    
    function SetWebsiteName($sitename)
    {
        $this->sitename = $sitename;
    }
    
    function SetRandomKey($key)
    {
        $this->rand_key = $key;
    }
    
    //-------Main Operations ----------------------
    function RegisterUser()
    {
        if(!isset($_POST['submitted']))
        {
           return false;
        }
        
        $formvars = array();
        
        if(!$this->ValidateRegistrationSubmission())
        {
            return false;
        }
        
        $this->CollectRegistrationSubmission($formvars);
        
        if(!$this->SaveToDatabase($formvars))
        {
            return false;
        }
        
        if(!$this->SendUserConfirmationEmail($formvars))
        {
            return false;
        }

        $this->SendAdminIntimationEmail($formvars);
        
        return true;
    }

    function ConfirmUser()
    {
        if(empty($_GET['code'])||strlen($_GET['code'])<=10)
        {
            $this->HandleError("Please provide the confirm code");
            return false;
        }
        $user_rec = array();
        if(!$this->UpdateDBRecForConfirmation($user_rec))
        {
            return false;
        }
        
        $this->SendUserWelcomeEmail($user_rec);
        
        $this->SendAdminIntimationOnRegComplete($user_rec);
        
        return true;
    }    
    
    function Login()
    {
        if(empty($_POST['username']))
        {
            $this->HandleError("UserName is empty!");
            return false;
        }
        
        if(empty($_POST['password']))
        {
            $this->HandleError("Password is empty!");
            return false;
        }
        
        $username = trim($_POST['username']);
        $password = trim($_POST['password']);
        
        if(!isset($_SESSION)){ session_start(); }
        if(!$this->CheckLoginInDB($username,$password))
        {
            return false;
        }
        
        $_SESSION[$this->GetLoginSessionVar()] = $username;
        
        return true;
    }
    
    function CheckLogin()
    {
         if(!isset($_SESSION)){ session_start(); }

         $sessionvar = $this->GetLoginSessionVar();
         
         if(empty($_SESSION[$sessionvar]))
         {
            return false;
         }
         return true;
    }
    
    function UserFullName()
    {
        return isset($_SESSION['name_of_user'])?$_SESSION['name_of_user']:'';
    }
    
    
    function UserEmail()
    {
        return isset($_SESSION['email_of_user'])?$_SESSION['email_of_user']:'';
    }
    
    function LogOut()
    {
        //session_start();
        
        $sessionvar = $this->GetLoginSessionVar();
        
        $_SESSION[$sessionvar]=NULL;
        
        unset($_SESSION[$sessionvar]);
    }
    
    function EmailResetPasswordLink()
    {   $e_mail = strtolower($_POST['email']);
        if(empty($e_mail))
        {
            $this->HandleError("Email is empty!");
            return false;
        }
        $user_rec = array();
        if(false === $this->GetUserFromEmail($e_mail, $user_rec))
        {
            return false;
        }
        if(false === $this->SendResetPasswordLink($user_rec))
        {
            return false;
        }
        return true;
    }
    
    function ResetPassword()
    {
        if(empty($_GET['email']))
        {
            $this->HandleError("Email is empty!");
            return false;
        }
        if(empty($_GET['code']))
        {
            $this->HandleError("reset code is empty!");
            return false;
        }
        $email = trim($_GET['email']);
        $code = trim($_GET['code']);
        
        if($this->GetResetPasswordCode($email) != $code)
        {
            $this->HandleError("Bad reset code!");
            return false;
        }
        
        $user_rec = array();
        if(!$this->GetUserFromEmail($email,$user_rec))
        {
            return false;
        }
        
        $new_password = $this->ResetUserPasswordInDB($user_rec);
        if(false === $new_password || empty($new_password))
        {
            $this->HandleError("Error updating new password");
            return false;
        }
        
        if(false == $this->SendNewPassword($user_rec,$new_password))
        {
            $this->HandleError("Error sending new password");
            return false;
        }
        return true;
    }
    
    function ChangePassword()
    {
        if(!$this->CheckLogin())
        {
            $this->HandleError("Not logged in!");
            return false;
        }
        
        if(empty($_POST['oldpwd']))
        {
            $this->HandleError("Old password is empty!");
            return false;
        }
        if(empty($_POST['newpwd']))
        {
            $this->HandleError("New password is empty!");
            return false;
        }
        
        $user_rec = array();
        if(!$this->GetUserFromEmail($this->UserEmail(),$user_rec))
        {
            return false;
        }
        
        $pwd = trim($_POST['oldpwd']);
        
        if(!password_verify($pwd, $user_rec['password']))
        {
            $this->HandleError("The old password does not match!");
            return false;
        }
        $newpwd = trim($_POST['newpwd']);
        
        if(!$this->ChangePasswordInDB($user_rec, $newpwd))
        {
            return false;
        }
        return true;
    }
    
    //-------Public Helper functions -------------
    function GetSelfScript()
    {
        return htmlentities($_SERVER['PHP_SELF']);
    }    
    
    function SafeDisplay($value_name)
    {
        if(empty($_POST[$value_name]))
        {
            return'';
        }
        return htmlentities($_POST[$value_name]);
    }
    
    function RedirectToURL($url)
    {
        header("Location: $url");
        exit;
    }
    
    function GetSpamTrapInputName()
    {
        return 'sp'.md5('KHGdnbvsgst'.$this->rand_key);
    }
    
    function GetErrorMessage()
    {
        if(empty($this->error_message))
        {
            return '';
        }
        $errormsg = nl2br(htmlentities($this->error_message));
        return $errormsg;
    }    
    //-------Private Helper functions-----------
    
    function HandleError($err)
    {
        $this->error_message .= $err."\r\n";
    }
    
    function HandleDBError($err)
    {
        $this->HandleError($err."\r\n mysqlerror:".mysqli_error($this->connection));
    }
   
    function GetLoginSessionVar()
    {
        $retvar = md5($this->rand_key);
        $retvar = 'usr_'.substr($retvar,0,10);
        return $retvar;
    }
    
    function CheckLoginInDB($field,$password)
    {
        if(!$this->DBLogin())
        {
            $this->HandleError("Database login failed!");
            return false;
        }          
        $field = $this->SanitizeForSQL($field);

        $uresult = mysqli_query($this->connection, 
          "SELECT * FROM $this->tablename WHERE username = '$field'") 
              or die(mysqli_error($this->connection));
        $eresult = mysqli_query($this->connection, 
          "SELECT * FROM $this->tablename WHERE email = '$field'") 
              or die(mysqli_error($this->connection));
          
        // check for result 
        $n_un = mysqli_num_rows($uresult);
        $n_de = mysqli_num_rows($eresult);
                
        if($n_un < 1 && $n_de < 1)
        {
            $this->HandleError("Error logging in. The username or password does not match");
            return false;
        }
        
        $vresult = "";
        if($n_un > 0) $vresult = $uresult;
        if($n_de > 0) $vresult = $eresult;

        $row = mysqli_fetch_assoc($vresult);
        if($row['confirmcode']!= 'y')
        {
            $this->HandleError("Error logging in. Complete your registration");
            return false;            
        }
        
        if($password != $row['password'])
        {  $this->HandleError("Error logging in. Either the username or password does not match");
            return false;
        }

        $_SESSION['name_of_user']  = $row['username'];
        $_SESSION['email_of_user'] = $row['email'];
        
        return true;
    }
   
    function UpdateDBRecForConfirmation(&$user_rec)
    {
        if(!$this->DBLogin())
        {
            $this->HandleError("Database login failed!");
            return false;
        }   
        $confirmcode = $this->SanitizeForSQL($_GET['code']);
        
        $result = mysqli_query($this->connection, "Select username, email from $this->tablename where confirmcode='$confirmcode'");   
        if(!$result || mysqli_num_rows($result) <= 0)
        {
            $this->HandleError("Wrong confirm code.");
            return false;
        }
        $row = mysqli_fetch_assoc($result);
        $user_rec['username'] = $row['username'];
        $user_rec['email']= $row['email'];
        
        $qry = "Update $this->tablename Set confirmcode='y' Where  confirmcode='$confirmcode'";
        
        if(!mysqli_query($this->connection, $qry ))
        {
            $this->HandleDBError("Error inserting data to the table\nquery:$qry");
            return false;
        }      
        return true;
    }
    
   function Complex()
   {
    $length = 12;    $charset = md5(uniqid()).'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890!@$%^&*()';    $encryption = '';    for($i = 0; $i < $length; $i++) {        $index = rand(0, strlen($charset) - 1);        $encryption .= $charset[$index]; } return $encryption;
   }

    function ResetUserPasswordInDB($user_rec)
    {
        $new_password =  $this->Complex();
        
        if(false == $this->ChangePasswordInDB($user_rec,$new_password))
        {
            return false;
        }
        return $new_password;
    }
    
    function ChangePasswordInDB($user_rec, $new_pwd)
    {
        $newpwd = trim($new_pwd);
        $qry = "Update $this->tablename Set password='".$newpwd."' Where  id_user=".$user_rec['id_user']."";
        
        if(!mysqli_query($this->connection, $qry))
        {
            $this->HandleDBError("Error updating the password \nquery:$qry");
            return false;
        }     
        return true;
    }
    
    function GetUserFromEmail($email,&$user_rec)
    {
        if(!$this->DBLogin())
        {
            $this->HandleError("Database login failed!");
            return false;
        }   
        $email = $this->SanitizeForSQL($email);
        
        $result = mysqli_query($this->connection, "Select * from $this->tablename where email='$email'");  

        if(!$result || mysqli_num_rows($result) <= 0)
        {
            $this->HandleError("There is no user with email: $email");
            return false;
        }
        $user_rec = mysqli_fetch_assoc($result);

        
        return true;
    }

function SendUserWelcomeEmail(&$user_rec)
    {
        $pmail = new PHPMailer();
            
        $pmail->AddAddress($user_rec['email'],$user_rec['username']);
        
        $pmail->Subject = "Welcome to Forex Autonomy";

        $pmail->Host = "smtp.gmail.com";       $pmail->SMTPAuth = true;        $pmail->SMTPSecure = "ssl";        $pmail->Port = 465;        $pmail->Username = "ijeawelae@gmail.com";        $pmail->Password = "pchrodiygckbrhpp";        $pmail->FromName = "Forex Autonomy";        $pmail->From = "no-reply@forexautonomy.com";

        $pmail->IsHTML(true);        $pmail->AltBody = GetSendUserWelcomeText($user_rec['username'],$pageuri);        $pmail->CharSet = 'UTF-8';        $pmail->Encoding='base64';
        
        $pageuri = $this->GetAbsoluteURLFolder()."/signin.php\r\n";
        
        $pmail->Body = GetSendUserWelcomeMessage($user_rec['username'],$pageuri);

        if(!$pmail->Send())
        {
            $this->HandleError("Failed sending user welcome email.");
            return false;
        }
        return true;
    }

    function SendAdminIntimationOnRegComplete(&$user_rec)
    {
        if(empty($this->admin_email))
        {
            return false;
        }
        $pmail = new PHPMailer();
        
        $pmail->Host = "smtp.gmail.com";       $pmail->SMTPAuth = true;        $pmail->SMTPSecure = "ssl";        $pmail->Port = 465;        $pmail->Username = "ijeawelae@gmail.com";        $pmail->Password = "pchrodiygckbrhpp";        $pmail->FromName = "Forex Autonomy";        $pmail->From = "no-reply@forexautonomy.com";

        $pmail->IsHTML(true);        $pmail->AltBody = GetAdminOnCompleteRegText($user_rec['username'],$user_rec['email']);        $pmail->CharSet = 'UTF-8';        $pmail->Encoding='base64';
        
        $pmail->AddAddress($this->admin_email);
        
        $pmail->Subject = "The Registration of ".$user_rec['username']." is complete.";
       
        $pmail->Body = GetAdminOnCompleteRegMessage($user_rec['username'],$user_rec['email']);
        
        if(!$pmail->Send())
        {
            return false;
        }
        return true;
    }
    
    function GetResetPasswordCode($email)
    {
       return substr(md5($email.$this->sitename.$this->rand_key),0,10);
    }
    
    function SendResetPasswordLink($user_rec)
    {
        $email = $user_rec['email'];
        
        $pmail = new PHPMailer();
        
        $pmail->Host = "smtp.gmail.com";       $pmail->SMTPAuth = true;        $pmail->SMTPSecure = "ssl";        $pmail->Port = 465;        $pmail->Username = "ijeawelae@gmail.com";        $pmail->Password = "pchrodiygckbrhpp";        $pmail->FromName = "Forex Autonomy";        $pmail->From = "no-reply@forexautonomy.com";

        $pmail->IsHTML(true);        $pmail->AltBody = GetResetPasswordText($user_rec['username'],$link);        $pmail->CharSet = 'UTF-8';        $pmail->Encoding='base64';
        
        $pmail->AddAddress($email,$user_rec['username']);
        
        $pmail->Subject = "Password reset requested for your Forex Autonomy account";
       
        $link = $this->GetAbsoluteURLFolder().
                '/passwordchanged.php?email='.
                urlencode($email).'&code='.
                urlencode($this->GetResetPasswordCode($email));

        $pmail->Body = GetResetPasswordMessage($user_rec['username'],$link);
        
        if(!$pmail->Send())
        {
            return false;
        }
        return true;
    }
    
    function SendNewPassword($user_rec, $new_password)
    {
        $email = $user_rec['email'];
        
        $pmail = new PHPMailer();
        
        $pmail->Host = "smtp.gmail.com";       $pmail->SMTPAuth = true;        $pmail->SMTPSecure = "ssl";        $pmail->Port = 465;        $pmail->Username = "ijeawelae@gmail.com";        $pmail->Password = "pchrodiygckbrhpp";        $pmail->FromName = "Forex Autonomy";        $pmail->From = "no-reply@forexautonomy.com";
 
        $pmail->IsHTML(true);        $pmail->AltBody = GetNewPasswordText($user_rec['username'],$loginlink,$new_password);        $pmail->CharSet = 'UTF-8';        $pmail->Encoding='base64';
        
        $pmail->AddAddress($email,$user_rec['username']);
        
        $pmail->Subject = "The new password for your Forex Autonomy account";
      
        $loginlink = $this->GetAbsoluteURLFolder()."/signin.php\r\n";
        $pmail->Body  = GetNewPasswordMessage($user_rec['username'],$loginlink,$new_password);
        
        if(!$pmail->Send()) return false; else $this->LogOut();
        return true;
    }    
    
    function ValidateRegistrationSubmission()
    {
        //This is a hidden input field. Humans won't fill this field.
        if(!empty($_POST[$this->GetSpamTrapInputName()]) )
        {
            //The proper error is not given intentionally
            $this->HandleError("Automated submission prevention: case 2 failed");
            return false;
        }
        $validator = new FormValidator();
        $validator->addValidation("username","req","Please fill in username");
        $validator->addValidation("email","email","The input for Email should be a valid email value");
        $validator->addValidation("email","req","Please fill in Email");
        $validator->addValidation("password","req","Please fill in Password");
        
        if(!$validator->ValidateForm())
        {
            $error='';
            $error_hash = $validator->GetErrors();
            foreach($error_hash as $inpname => $inp_err)
            {
                $error .= $inpname.':'.$inp_err."\n";
            }
            $this->HandleError($error);
            return false;
        }        
        return true;
    }
    
    function CollectRegistrationSubmission(&$formvars)
    {
	$formvars['username'] = $this->Sanitize($_POST['username']);
    $e_mail = strtolower($_POST['email']);
    $formvars['email'] = $this->Sanitize($e_mail);
    $formvars['password'] = $this->Sanitize($_POST['password']);
   
    }
    
function SendUserConfirmationEmail(&$formvars)
    {
        $pmail = new PHPMailer();
        
        $pmail->Host = "smtp.gmail.com";       $pmail->SMTPAuth = true;        $pmail->SMTPSecure = "ssl";        $pmail->Port = 465;        $pmail->Username = "ijeawelae@gmail.com";        $pmail->Password = "pchrodiygckbrhpp";        $pmail->FromName = "Forex Autonomy";        $pmail->From = "no-reply@forexautonomy.com";
        
        $pmail->IsHTML(true);        $pmail->AltBody = GetUserConfirmationText($confirm_url);        $pmail->CharSet = 'UTF-8';        $pmail->Encoding='base64';
        
        $pmail->AddAddress($formvars['email'],$formvars['username']);
        
        $pmail->Subject = "You just signed up on Forex Autonomy. Please verify your account";

        $confirmcode = $formvars['confirmcode'];
        
        $confirm_url = $this->GetAbsoluteURLFolder().'/confirmsignup.php?code='.$confirmcode;
        
        $pmail->Body = GetUserConfirmationMessage($confirm_url);
        
        if(!$pmail->Send())
        {
            $this->HandleError("Failed sending registration confirmation email.");
            return false;
        }
        return true;
    }


    function GetAbsoluteURLFolder()
    {
        $scriptFolder = (isset($_SERVER['HTTPS']) && ($_SERVER['HTTPS'] == 'on')) ? 'https://' : 'http://';

        $urldir ='';
        $pos = strrpos($_SERVER['REQUEST_URI'],'/');
        if(false !==$pos)
        {
            $urldir = substr($_SERVER['REQUEST_URI'],0,$pos);
        }

        $scriptFolder .= $_SERVER['HTTP_HOST'].$urldir;

        return $scriptFolder;
    }
    
    function SendAdminIntimationEmail(&$formvars)
    {
        if(empty($this->admin_email))
        {
            return false;
        }
        $pmail = new PHPMailer();
        
        $pmail->Host = "smtp.gmail.com";       $pmail->SMTPAuth = true;        $pmail->SMTPSecure = "ssl";        $pmail->Port = 465;        $pmail->Username = "ijeawelae@gmail.com";        $pmail->Password = "pchrodiygckbrhpp";        $pmail->FromName = "Forex Autonomy";        $pmail->From = "no-reply@forexautonomy.com";
  
        $pmail->IsHTML(true);        $pmail->AltBody = GetAdminIntimationText($formvars['username'],$formvars['email']);        $pmail->CharSet = 'UTF-8';        $pmail->Encoding='base64';
        
        $pmail->AddAddress($this->admin_email);
        
        $pmail->Subject = "New registration: ".$formvars['username'];
       
        $pmail->Body = GetAdminIntimationMessage($formvars['username'],$formvars['email']);
                
        if(!$pmail->Send())
        {
            return false;
        }
        return true;
    }
    
    function SaveToDatabase(&$formvars)
    {
        if(!$this->DBLogin())
        {
            $this->HandleError("Database login failed!");
            return false;
        }
        if(!$this->Ensuretable())
        {
            return false;
        }
        if(!$this->IsFieldUnique($formvars,'email'))
        {
            $this->HandleError("This email is already registered");
            return false;
        }
        
	if(!$this->IsFieldUnique($formvars,'username'))
        {
            $this->HandleError("This UserName is already used. Please try another username");
            return false;
        } 
              
        if(!$this->InsertIntoDB($formvars))
        {
            $this->HandleError("Inserting to Database failed!");
            return false;
        }
        return true;
    }
    
    function IsFieldUnique($formvars,$fieldname)
    {
        $field_val = $this->SanitizeForSQL($formvars[$fieldname]);
        $qry = "select username from $this->tablename where $fieldname='".$field_val."'";
        $result = mysqli_query($this->connection, $qry);   
        if($result && mysqli_num_rows($result) > 0)
        {
            return false;
        }
        return true;
    }
    
    function DBLogin()
    {

        $this->connection = mysqli_connect($this->db_host,$this->username,$this->pwd, $this->database);

        if(!$this->connection)
        {   
            $this->HandleDBError("Database Login failed! Please make sure that the DB login credentials provided are correct");
            return false;
        }
        if(!mysqli_select_db($this->connection, $this->database))
        {
            $this->HandleDBError('Failed to select database: '.$this->database.' Please make sure that the database name provided is correct');
            return false;
        }
        if(!mysqli_query($this->connection, "SET NAMES 'UTF8'"))
        {
            $this->HandleDBError('Error setting utf8 encoding');
            return false;
        }
        return true;
    }    
    
    function Ensuretable()
    {
        $result = mysqli_query($this->connection, "SHOW COLUMNS FROM $this->tablename");   
        if(!$result || mysqli_num_rows($result) <= 0)
        {
            return $this->CreateTable();
        }
        return true;
    }

    function CreateTable()
    {
       
    	$qry = "Create Table $this->tablename (".
                "id INT NOT NULL AUTO_INCREMENT ,".
                "firstname VARCHAR( 64 ) NOT NULL ,".
                "lastname VARCHAR( 64 ) NOT NULL ,".
                "email VARCHAR( 64 ) NOT NULL ,".
                "username VARCHAR( 64 ) NOT NULL ,".
                "phone VARCHAR( 14 ) ,".
                "password VARCHAR( 255 ) NOT NULL ,".
                "confirmcode VARCHAR(32) ,".
                "source ENUM('google', 'forexautonomy', 'twitter', 'linkedin', 'facebook') NOT NULL DEFAULT 'forexautonomy' ,".
                "PRIMARY KEY ( id ) ,".
                "registrationdate TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP".
                ")";
	
                
        if(!mysqli_query($this->connection, $qry))
        {
            $this->HandleDBError("Error creating the table \nquery was\n $qry");
            return false;
        }
        return true;
    }
    
    function InsertIntoDB(&$formvars)
    {
    
        $confirmcode = $this->MakeConfirmationMd5($formvars['email']);

        $formvars['confirmcode'] = $confirmcode;
        
        $password = trim($formvars['password']);
        
        $encrypted_password = password_hash($password, PASSWORD_DEFAULT);
        
 
        $insert_query = 'insert into '.$this->tablename.'(
		username,
		email,
		password,
		confirmcode
		)
		values
		(
		"' . $this->SanitizeForSQL($formvars['username']) . '",
		"' . $this->SanitizeForSQL($formvars['email']) . '",
		"' . $password . '",
		"' . $confirmcode . '"
		)';  

 
        if(!mysqli_query($this->connection, $insert_query ))
        {
            $this->HandleDBError("Error inserting data to the table\nquery:$insert_query");
            return false;
        }        
        return true;
    }

    function MakeConfirmationMd5($email)
    {
        $randno1 = rand();
        $randno2 = rand();
        return md5($email.$this->rand_key.$randno1.''.$randno2);
    }
    function SanitizeForSQL($str)
    {
        if( function_exists( "mysqli_real_escape_string" ) )
        {
              $ret_str = mysqli_real_escape_string($this->connection, $str );
        }
        else
        {
              $ret_str = addslashes( $str );
        }
        return $ret_str;
    }
    
 /*
    Sanitize() function removes any potential threat from the
    data submitted. Prevents email injections or any other hacker attempts.
    if $remove_nl is true, newline chracters are removed from the input.
    */
    function Sanitize($str,$remove_nl=true)
    {
        $str = $this->StripSlashes($str);

        if($remove_nl)
        {
            $injections = array('/(\n+)/i',
                '/(\r+)/i',
                '/(\t+)/i',
                '/(%0A+)/i',
                '/(%0D+)/i',
                '/(%08+)/i',
                '/(%09+)/i'
                );
            $str = preg_replace($injections,'',$str);
        }

        return $str;
    }    
    function StripSlashes($str)
    {
        if(get_magic_quotes_gpc())
        {
            $str = stripslashes($str);
        }
        return $str;
    }    
}

