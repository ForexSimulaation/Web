<?PHP
include("/home/tecvidjt/public_html/cls.php");
?>
<!DOCTYPE html>
<html lang="en" class="dark">
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head>
<meta charset="UTF-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Frequently Asked Questions | Glossary</title>
<meta name="title" content="Forex Trading Automation" />
<meta name="description" content="Welcome to the World of Band Trading" />

<meta property="og:type" content="website" />
<meta property="og:url" content="forexautonomy.com" />
<meta property="og:title" content="Welcome to the World of Band Trading" />
<meta property="og:description" content="Two Synchronized Accounts in most instances result in a net positive growth irrespective of the direction of the market." />
<meta property="og:image" content="#" />

<meta property="twitter:card" content="summary_large_image" />
<meta property="twitter:url" content="https://www.twitter.com/forexautonomy" />
<meta property="twitter:title" content="Forex Autonomy, Automate Everything!" />
<meta property="twitter:description" content="Forex Autonomy, Automate Everything!" />
<meta property="twitter:image" content="#" />
<link rel="icon" href="favicon.ico"><link href="style.css" rel="stylesheet"><link href="faq.css" rel="stylesheet"></head>
<body class="dark:bg-black">

<header class="header bg-transparent absolute top-0 left-0 z-40 w-full flex items-center">
<div class="container">
<div class="flex mx-[-16px] items-center justify-between relative">
<div class="px-4 w-60 max-w-full">
<a href="index" class="w-full block py-8 header-logo">
<img src="images/logo-2.svg" alt="logo" class="w-full dark:hidden" />
<img src="images/logo.svg" alt="logo" class="w-full hidden dark:block" />
</a>
</div>
<div class="flex px-4 justify-between items-center w-full">
<div>
<nav id="navbarCollapse" class="absolute py-5 lg:py-0 lg:px-4 xl:px-6 bg-white dark:bg-dark lg:dark:bg-transparent lg:bg-transparent shadow-lg rounded-lg max-w-[250px] w-full lg:max-w-full lg:w-full right-4 top-full hidden lg:block lg:static lg:shadow-none">
<ul class="blcok lg:flex">
<li class="relative group">
<a href="index" class="menu-scroll text-base text-dark dark:text-white group-hover:opacity-70 py-2 lg:py-6 lg:inline-flex lg:px-0 flex mx-8 lg:mr-0">
Forex
</a>
</li>
<li class="relative group submenu-item">
<a href="bandtrading" class="text-base text-dark dark:text-white group-hover:opacity-70 py-2 lg:py-6 lg:inline-flex lg:pl-0 lg:pr-4 flex mx-8 lg:mr-0 lg:ml-8 xl:ml-12 relative after:absolute after:w-2 after:h-2 after:border-b-2 after:border-r-2 after:border-current after:rotate-45 lg:after:right-0 after:right-1 after:top-1/2 after:translate-y-[-50%] after:mt-[-2px]">
Autonomy
</a>
<div class="submenu hidden relative lg:absolute w-[250px] top-full lg:top-[110%] left-0 rounded-md lg:shadow-lg p-4 lg:block lg:opacity-0 lg:invisible group-hover:opacity-100 lg:group-hover:visible lg:group-hover:top-full bg-white dark:bg-dark transition-[top] duration-300">
<a href="bandtrading.cloudservice" class="block text-sm rounded py-[10px] px-4 text-dark dark:text-white hover:opacity-70"> Cloud Service </a>
<a href="bandtrading.ownership" class="block text-sm rounded py-[10px] px-4 text-dark dark:text-white hover:opacity-70"> Standalone Replication </a>
<a href="bandtrading.verification" class="block text-sm rounded py-[10px] px-4 text-dark dark:text-white hover:opacity-70"> Transparent Records </a>
</div></li>
<li class="relative group submenu-item">
<a href="tools" class="text-base text-dark dark:text-white group-hover:opacity-70 py-2 lg:py-6 lg:inline-flex lg:pl-0 lg:pr-4 flex mx-8 lg:mr-0 lg:ml-8 xl:ml-12 relative after:absolute after:w-2 after:h-2 after:border-b-2 after:border-r-2 after:border-current after:rotate-45 lg:after:right-0 after:right-1 after:top-1/2 after:translate-y-[-50%] after:mt-[-2px]">
Tools
</a>
<div class="submenu hidden relative lg:absolute w-[250px] top-full lg:top-[110%] left-0 rounded-md lg:shadow-lg p-4 lg:block lg:opacity-0 lg:invisible group-hover:opacity-100 lg:group-hover:visible lg:group-hover:top-full bg-white dark:bg-dark transition-[top] duration-300">
<a href="account.protector" class="block text-sm rounded py-[10px] px-4 text-dark dark:text-white hover:opacity-70"> Account Protector </a>
<a href="auto.trailing.assistant" class="block text-sm rounded py-[10px] px-4 text-dark dark:text-white hover:opacity-70"> Auto Trailing Assistant </a>
<a href="earn.market.service" class="block text-sm rounded py-[10px] px-4 text-dark dark:text-white hover:opacity-70"> Earn Market Service </a>
<a href="versatile.trade.copier" class="block text-sm rounded py-[10px] px-4 text-dark dark:text-white hover:opacity-70"> Versatile Trade Copier </a>
<a href="intelligent.trader"" class="block text-sm rounded py-[10px] px-4 text-dark dark:text-white hover:opacity-70"> Intelligent Zones Trader </a>
<a href="ultimate.support.resistance.zones.indicator" class="block text-sm rounded py-[10px] px-4 text-dark dark:text-white hover:opacity-70"> Zones Indicator </a>
<a href="freebies" class="block text-sm rounded py-[10px] px-4 text-dark dark:text-white hover:opacity-70"> Free Indicators and Robots </a>
<a href="tradingview.metatrader" class="block text-sm rounded py-[10px] px-4 text-dark dark:text-white hover:opacity-70"> TradingView to MetaTrader </a></div></li>
<li class="relative group">
<a href="support" class="menu-scroll text-base text-dark dark:text-white group-hover:opacity-70 py-2 lg:py-6 lg:inline-flex lg:px-0 flex mx-8 lg:mr-0 lg:ml-8 xl:ml-12">
Support
</a>
</li>
<li class="relative group submenu-item">
<a href="javascript:void(0)" class="text-base text-dark dark:text-white group-hover:opacity-70 py-2 lg:py-6 lg:inline-flex lg:pl-0 lg:pr-4 flex mx-8 lg:mr-0 lg:ml-8 xl:ml-12 relative after:absolute after:w-2 after:h-2 after:border-b-2 after:border-r-2 after:border-current after:rotate-45 lg:after:right-0 after:right-1 after:top-1/2 after:translate-y-[-50%] after:mt-[-2px]">
Navigate
</a>
<div class="submenu hidden relative lg:absolute w-[250px] top-full lg:top-[110%] left-0 rounded-md lg:shadow-lg p-4 lg:block lg:opacity-0 lg:invisible group-hover:opacity-100 lg:group-hover:visible lg:group-hover:top-full bg-white dark:bg-dark transition-[top] duration-300">
<a href="blog" class="block text-sm rounded py-[10px] px-4 text-dark dark:text-white hover:opacity-70"> Blog </a>
<a href="kellycriterion" class="block text-sm rounded py-[10px] px-4 text-dark dark:text-white hover:opacity-70"> Kelly Criterion </a>
<a href="faq" class="block text-sm rounded py-[10px] px-4 text-dark dark:text-white hover:opacity-70"> Frequently Asked Questions </a>
</div>
</li>
</ul>
</nav>
</div>
<div class="flex justify-end items-center pr-16 lg:pr-0">
<?php echo everyPage($state)?>
<div>
<label for="darkToggler" class="cursor-pointer w-9 h-9 md:w-14 md:h-14 rounded-full flex items-center justify-center bg-gray-2 dark:bg-dark-bg text-black dark:text-white">
<input type="checkbox" name="darkToggler" id="darkToggler" class="sr-only" aria-label="darkToggler" />
</label>
</div>
</div>
</div>
</div>
</div>
</header>


<section id="faq" x-data="
{
  openFaq1: false,
  openFaq2: false,
  openFaq3: false,
  openFaq4: false,
  openFaq5: false,
}
" class="e ca nf ih ml">
<div class="a">
<div class="wow fadeInUp la fb ld fi qn" data-wow-delay="0s">
  <br><br><br><br>
<span class="va gi pi ri bj fn">
FAQ
</span>
<h2 class="va li pi ui yi vl bo">
Frequently Asked Questions
</h2>
<p class="la id gi qi xi ul">
If what you inquire about is not here, please simply fill out your request on the contact page.
</p>
</div>
<div class="ha qb _d de">
<div class="jc ng _o/12 jq/12">
<div class="single-faq wow fadeInUp ra me kf ah ch gl zn _n" data-wow-delay="0s">
<button @click="openFaq1 = !openFaq1" class="faq-btn qb jc be ee ei">
<h3 class="kb ii pi aj vl dn co">
Automated Trading System (ATS)
</h3>
<span class="icon rb gc jc md be de ne wf zi yl pl gi oi" :class="openFaq1 && 'ud' ">
<svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
<g clip-path="url(#clip0_50_132)">
<path d="M8.82033 1.91065L4.99951 5.73146L1.17869 1.91064L-0.000488487 3.08978L4.99951 8.08978L9.99951 3.08979L8.82033 1.91065Z" fill="currentColor" />
</g>
<defs>
<clipPath id="clip0_50_132">
<rect width="10" height="10" fill="white" transform="translate(-0.000488281 0.000488281)" />
</clipPath>
</defs>
</svg>
</span>
</button>
<div x-show="openFaq1" class="faq-content">
<p class="ar bi ii xi ul">
The use of trading robots, and artificial intelligence to make all trading and investment decisions in forex, stock and cryptocurrency markets.
</p>
</div>
</div>
<div class="single-faq wow fadeInUp ra me kf ah ch gl zn _n" data-wow-delay="0s">
<button @click="openFaq2 = !openFaq2" class="faq-btn qb jc be ee ei">
<h3 class="kb ii pi aj vl dn co">
Band Trading
</h3>
<span class="icon rb gc jc md be de ne wf zi yl pl gi oi" :class="openFaq2 && 'ud' ">
<svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
<g clip-path="url(#clip0_50_132)">
<path d="M8.82033 1.91065L4.99951 5.73146L1.17869 1.91064L-0.000488487 3.08978L4.99951 8.08978L9.99951 3.08979L8.82033 1.91065Z" fill="currentColor" />
</g>
<defs>
<clipPath id="clip0_50_132">
<rect width="10" height="10" fill="white" transform="translate(-0.000488281 0.000488281)" />
</clipPath>
</defs>
</svg>
</span>
</button>
<div x-show="openFaq2" class="faq-content">
<p class="ar bi ii xi ul">
A forex CFD grid trading system that increases earnings as long as sufficient price change occurs in either direction of the market.
Band Trading enables a trader to repeatedly florish against the notorious randomness of the markets.
It also allows a trader to repeatedly enter and exit markets with minimal financial risk.
</p>
</div>
</div>
<div class="single-faq wow fadeInUp ra me kf ah ch gl zn _n" data-wow-delay="0s">
<button @click="openFaq3 = !openFaq3" class="faq-btn qb jc be ee ei">
<h3 class="kb ii pi aj vl dn co">
Kelly Criterion
</h3>
<span class="icon rb gc jc md be de ne wf zi yl pl gi oi" :class="openFaq3 && 'ud' ">
<svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
<g clip-path="url(#clip0_50_132)">
<path d="M8.82033 1.91065L4.99951 5.73146L1.17869 1.91064L-0.000488487 3.08978L4.99951 8.08978L9.99951 3.08979L8.82033 1.91065Z" fill="currentColor" />
</g>
<defs>
<clipPath id="clip0_50_132">
<rect width="10" height="10" fill="white" transform="translate(-0.000488281 0.000488281)" />
</clipPath>
</defs>
</svg>
</span>
</button>
<div x-show="openFaq3" class="faq-content">
<p class="ar bi ii xi ul">
  A scientific gambling method that has been proven over and over again in real circumstances.
  For the average forex retail trader who trades manually, money management is the most important thing to master.
</p>
</div>
</div>
<div class="single-faq wow fadeInUp ra me kf ah ch gl zn _n" data-wow-delay="0s">
<button @click="openFaq4 = !openFaq4" class="faq-btn qb jc be ee ei">
<h3 class="kb ii pi aj vl dn co">
90/90/90 rule
</h3>
<span class="icon rb gc jc md be de ne wf zi yl pl gi oi" :class="openFaq4 && 'ud' ">
<svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
<g clip-path="url(#clip0_50_132)">
<path d="M8.82033 1.91065L4.99951 5.73146L1.17869 1.91064L-0.000488487 3.08978L4.99951 8.08978L9.99951 3.08979L8.82033 1.91065Z" fill="currentColor" />
</g>
<defs>
<clipPath id="clip0_50_132">
<rect width="10" height="10" fill="white" transform="translate(-0.000488281 0.000488281)" />
</clipPath>
</defs>
</svg>
</span>
</button>
<div x-show="openFaq4" class="faq-content">
<p class="ar bi ii xi ul">
In retail forex trading, 90% of traders are known to lose 90% of their trading investment within 90 days. This notorious statistic can only be crushed with automated trading.
</p>
</div>
</div>
</div>
</div>
</div>
</section>




<footer class="relative z-10 bg-primary bg-opacity-5 pt-[100px] wow fadeInUp" data-wow-delay=".1s">
<div class="container">
<div class="flex flex-wrap mx-[-16px]">
<div class="w-full md:w-1/2 lg:w-4/12 xl:w-5/12 px-4">
<div class="mb-16 max-w-[360px]">
<a href="index" class="inline-block mb-8">
<img src="images/logo-2.svg" alt="logo" class="w-full dark:hidden" />
<img src="images/logo.svg" alt="logo" class="w-full hidden dark:block" />
</a>
<p class="text-body-color text-base font-medium leading-relaxed mb-9">The healthiest trading practice today, is utilizing advanced algorithms to perpertually conquer the financial markets.</p>
<div class="flex items-center">
<a href="https://www.facebook.com/forexautonomy" aria-label="social-link" class="text-[#CED3F6] hover:text-primary mr-6">
 <svg width="9" height="18" viewBox="0 0 9 18" class="fill-current">
<path d="M8.13643 7H6.78036H6.29605V6.43548V4.68548V4.12097H6.78036H7.79741C8.06378 4.12097 8.28172 3.89516 8.28172 3.55645V0.564516C8.28172 0.254032 8.088 0 7.79741 0H6.02968C4.11665 0 2.78479 1.58064 2.78479 3.92339V6.37903V6.94355H2.30048H0.65382C0.314802 6.94355 0 7.25403 0 7.70564V9.7379C0 10.1331 0.266371 10.5 0.65382 10.5H2.25205H2.73636V11.0645V16.7379C2.73636 17.1331 3.00273 17.5 3.39018 17.5H5.66644C5.81174 17.5 5.93281 17.4153 6.02968 17.3024C6.12654 17.1895 6.19919 16.9919 6.19919 16.8226V11.0927V10.5282H6.70771H7.79741C8.11222 10.5282 8.35437 10.3024 8.4028 9.96371V9.93548V9.90726L8.74182 7.95968C8.76604 7.7621 8.74182 7.53629 8.59653 7.31048C8.54809 7.16935 8.33016 7.02823 8.13643 7Z" />
</svg>
</a>
<a href="https://www.twitter.com/forexautonomy" aria-label="social-link" class="text-[#CED3F6] hover:text-primary mr-6">
<svg width="19" height="14" viewBox="0 0 19 14" class="fill-current">
<path d="M16.3024 2.26027L17.375 1.0274C17.6855 0.693493 17.7702 0.436644 17.7984 0.308219C16.9516 0.770548 16.1613 0.924658 15.6532 0.924658H15.4556L15.3427 0.821918C14.6653 0.282534 13.8185 0 12.9153 0C10.9395 0 9.3871 1.48973 9.3871 3.21062C9.3871 3.31336 9.3871 3.46747 9.41532 3.57021L9.5 4.0839L8.90726 4.05822C5.29435 3.95548 2.33065 1.13014 1.85081 0.642123C1.06048 1.92637 1.5121 3.15925 1.99194 3.92979L2.95161 5.36815L1.42742 4.5976C1.45565 5.67637 1.90726 6.52397 2.78226 7.14041L3.54435 7.65411L2.78226 7.93665C3.2621 9.24658 4.33468 9.78596 5.125 9.99144L6.16935 10.2483L5.18145 10.8647C3.60081 11.8921 1.625 11.8151 0.75 11.738C2.52823 12.8682 4.64516 13.125 6.1129 13.125C7.21371 13.125 8.03226 13.0223 8.22984 12.9452C16.1331 11.25 16.5 4.82877 16.5 3.54452V3.36473L16.6694 3.26199C17.629 2.44007 18.0242 2.00342 18.25 1.74658C18.1653 1.77226 18.0524 1.82363 17.9395 1.84932L16.3024 2.26027Z" />
</svg>
</a>
<a href="https://www.youtube.com/@forexautonomy" aria-label="social-link" class="text-[#CED3F6] hover:text-primary mr-6">
<svg width="18" height="14" viewBox="0 0 18 14" class="fill-current">
<path d="M17.5058 2.07119C17.3068 1.2488 16.7099 0.609173 15.9423 0.395963C14.5778 7.26191e-08 9.0627 0 9.0627 0C9.0627 0 3.54766 7.26191e-08 2.18311 0.395963C1.41555 0.609173 0.818561 1.2488 0.619565 2.07119C0.25 3.56366 0.25 6.60953 0.25 6.60953C0.25 6.60953 0.25 9.68585 0.619565 11.1479C0.818561 11.9703 1.41555 12.6099 2.18311 12.8231C3.54766 13.2191 9.0627 13.2191 9.0627 13.2191C9.0627 13.2191 14.5778 13.2191 15.9423 12.8231C16.7099 12.6099 17.3068 11.9703 17.5058 11.1479C17.8754 9.68585 17.8754 6.60953 17.8754 6.60953C17.8754 6.60953 17.8754 3.56366 17.5058 2.07119ZM7.30016 9.44218V3.77687L11.8771 6.60953L7.30016 9.44218Z" />
</svg>
</a>
<a href="https://www.linkedin.com/forexautonomy" aria-label="social-link" class="text-[#CED3F6] hover:text-primary mr-6">
<svg width="17" height="16" viewBox="0 0 17 16" class="fill-current">
<path d="M15.2196 0H1.99991C1.37516 0 0.875366 0.497491 0.875366 1.11936V14.3029C0.875366 14.8999 1.37516 15.4222 1.99991 15.4222H15.1696C15.7943 15.4222 16.2941 14.9247 16.2941 14.3029V1.09448C16.3441 0.497491 15.8443 0 15.2196 0ZM5.44852 13.1089H3.17444V5.7709H5.44852V13.1089ZM4.29899 4.75104C3.54929 4.75104 2.97452 4.15405 2.97452 3.43269C2.97452 2.71133 3.57428 2.11434 4.29899 2.11434C5.02369 2.11434 5.62345 2.71133 5.62345 3.43269C5.62345 4.15405 5.07367 4.75104 4.29899 4.75104ZM14.07 13.1089H11.796V9.55183C11.796 8.7061 11.771 7.58674 10.5964 7.58674C9.39693 7.58674 9.222 8.53198 9.222 9.47721V13.1089H6.94792V5.7709H9.17202V6.79076H9.19701C9.52188 6.19377 10.2466 5.59678 11.3711 5.59678C13.6952 5.59678 14.12 7.08925 14.12 9.12897V13.1089H14.07Z" />
</svg>
</a>
</div>
</div>
</div>
<div class="w-full sm:w-1/2 md:w-1/2 lg:w-2/12 xl:w-2/12 px-4">
<div class="mb-16">
<h2 class="font-bold text-black dark:text-white text-xl mb-10">Useful Links</h2>
<ul>
<li>
<a href="blog" class="text-base font-medium inline-block text-body-color mb-4 hover:text-primary"> Blog </a>
</li>
<li>
<a href="tools" class="text-base font-medium inline-block text-body-color mb-4 hover:text-primary"> Tools </a>
</li>
<li>
<a href="ourteam" class="text-base font-medium inline-block text-body-color mb-4 hover:text-primary"> Who We Are </a>
</li>
</ul>
</div>
</div>
<div class="w-full sm:w-1/2 md:w-1/2 lg:w-2/12 xl:w-2/12 px-4">
<div class="mb-16">
<h2 class="font-bold text-black dark:text-white text-xl mb-10">Terms</h2>
<ul>
<li>
<a href="terms.of.service" class="text-base font-medium inline-block text-body-color mb-4 hover:text-primary"> Terms of Service </a>
</li>
<li>
<a href="privacy.policy" class="text-base font-medium inline-block text-body-color mb-4 hover:text-primary"> Privacy Policy </a>
</li>
<li>
<a href="refund.policy" class="text-base font-medium inline-block text-body-color mb-4 hover:text-primary"> Refund Policy </a>
</li>
</ul>
</div>
</div>
<div class="w-full md:w-1/2 lg:w-4/12 xl:w-3/12 px-4">
<div class="mb-16">
<h2 class="font-bold text-black dark:text-white text-xl mb-10">Support & Help</h2>
<ul>
<li>
<a href="support" class="text-base font-medium inline-block text-body-color mb-4 hover:text-primary"> Open Support Ticket </a>
</li>
<li>
<a href="catalogue" class="text-base font-medium inline-block text-body-color mb-4 hover:text-primary"> Catalogue </a>
</li>
<li>
<a href="algo.development" class="text-base font-medium inline-block text-body-color mb-4 hover:text-primary"> EA Development </a>
</li>
</ul>
</div>
</div>
</div>
</div>
<div class="py-8 bg-primary bg-opacity-10">
<div class="container">
<p class="text-body-color dark:text-white text-base text-center">&copy;<script>document.write(new Date().getFullYear());</script> Forex Autonomy</p>
</div>
</div>
<div class="absolute right-0 top-14 z-[-1]">
<svg width="55" height="99" viewBox="0 0 55 99" fill="none" xmlns="http://www.w3.org/2000/svg">
<circle opacity="0.8" cx="49.5" cy="49.5" r="49.5" fill="#959CB1" />
<mask id="mask0_94:899" style="mask-type: alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="99" height="99">
<circle opacity="0.8" cx="49.5" cy="49.5" r="49.5" fill="#4A6CF7" />
</mask>
<g mask="url(#mask0_94:899)">
<circle opacity="0.8" cx="49.5" cy="49.5" r="49.5" fill="url(#paint0_radial_94:899)" />
<g opacity="0.8" filter="url(#filter0_f_94:899)">
<circle cx="53.8676" cy="26.2061" r="20.3824" fill="white" />
</g>
</g>
<defs>
<filter id="filter0_f_94:899" x="12.4852" y="-15.1763" width="82.7646" height="82.7646" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
<feFlood flood-opacity="0" result="BackgroundImageFix" />
<feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
<feGaussianBlur stdDeviation="10.5" result="effect1_foregroundBlur_94:899" />
</filter>
<radialGradient id="paint0_radial_94:899" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(49.5 49.5) rotate(90) scale(53.1397)">
<stop stop-opacity="0.47" />
<stop offset="1" stop-opacity="0" />
</radialGradient>
</defs>
</svg>
</div>
<div class="absolute left-0 bottom-24 z-[-1]">
<svg width="79" height="94" viewBox="0 0 79 94" fill="none" xmlns="http://www.w3.org/2000/svg">
<rect opacity="0.3" x="-41" y="26.9426" width="66.6675" height="66.6675" transform="rotate(-22.9007 -41 26.9426)" fill="url(#paint0_linear_94:889)" />
<rect x="-41" y="26.9426" width="66.6675" height="66.6675" transform="rotate(-22.9007 -41 26.9426)" stroke="url(#paint1_linear_94:889)" stroke-width="0.7" />
<path opacity="0.3" d="M50.5215 7.42229L20.325 1.14771L46.2077 62.3249L77.1885 68.2073L50.5215 7.42229Z" fill="url(#paint2_linear_94:889)" />
<path d="M50.5215 7.42229L20.325 1.14771L46.2077 62.3249L76.7963 68.2073L50.5215 7.42229Z" stroke="url(#paint3_linear_94:889)" stroke-width="0.7" />
<path opacity="0.3" d="M17.9721 93.3057L-14.9695 88.2076L46.2077 62.325L77.1885 68.2074L17.9721 93.3057Z" fill="url(#paint4_linear_94:889)" />
<path d="M17.972 93.3057L-14.1852 88.2076L46.2077 62.325L77.1884 68.2074L17.972 93.3057Z" stroke="url(#paint5_linear_94:889)" stroke-width="0.7" />
<defs>
<linearGradient id="paint0_linear_94:889" x1="-41" y1="21.8445" x2="36.9671" y2="59.8878" gradientUnits="userSpaceOnUse">
<stop stop-color="#4A6CF7" stop-opacity="0.62" />
<stop offset="1" stop-color="#4A6CF7" stop-opacity="0" />
</linearGradient>
<linearGradient id="paint1_linear_94:889" x1="25.6675" y1="95.9631" x2="-42.9608" y2="20.668" gradientUnits="userSpaceOnUse">
<stop stop-color="#4A6CF7" stop-opacity="0" />
<stop offset="1" stop-color="#4A6CF7" stop-opacity="0.51" />
</linearGradient>
<linearGradient id="paint2_linear_94:889" x1="20.325" y1="-3.98039" x2="90.6248" y2="25.1062" gradientUnits="userSpaceOnUse">
<stop stop-color="#4A6CF7" stop-opacity="0.62" />
<stop offset="1" stop-color="#4A6CF7" stop-opacity="0" />
</linearGradient>
<linearGradient id="paint3_linear_94:889" x1="18.3642" y1="-1.59742" x2="113.9" y2="80.6826" gradientUnits="userSpaceOnUse">
<stop stop-color="#4A6CF7" stop-opacity="0" />
<stop offset="1" stop-color="#4A6CF7" stop-opacity="0.51" />
</linearGradient>
<linearGradient id="paint4_linear_94:889" x1="61.1098" y1="62.3249" x2="-8.82468" y2="58.2156" gradientUnits="userSpaceOnUse">
<stop stop-color="#4A6CF7" stop-opacity="0.62" />
<stop offset="1" stop-color="#4A6CF7" stop-opacity="0" />
</linearGradient>
<linearGradient id="paint5_linear_94:889" x1="65.4236" y1="65.0701" x2="24.0178" y2="41.6598" gradientUnits="userSpaceOnUse">
<stop stop-color="#4A6CF7" stop-opacity="0" />
<stop offset="1" stop-color="#4A6CF7" stop-opacity="0.51" />
</linearGradient>
</defs>
</svg>
</div>
</footer>

<a href="javascript:void(0)" class="hidden items-center justify-center bg-primary text-white w-10 h-10 rounded-md fixed bottom-8 right-8 left-auto z-[999] hover:shadow-signUp hover:bg-opacity-80 transition duration-300 ease-in-out back-to-top shadow-md">
<span class="w-3 h-3 border-t border-l border-white rotate-45 mt-[6px]"></span>
</a>
<script defer src="faq.js"></script><script>(function(){var js = "window['__CF$cv$params']={r:'7eeed5fa6a390086'};_cpo=document.createElement('script');_cpo.nonce='',_cpo.src='cdn-cgi/challenge-platform/h/b/scripts/jsd/11b725eb/invisible.js',document.getElementsByTagName('head')[0].appendChild(_cpo);";var _0xh = document.createElement('iframe');_0xh.height = 1;_0xh.width = 1;_0xh.style.position = 'absolute';_0xh.style.top = 0;_0xh.style.left = 0;_0xh.style.border = 'none';_0xh.style.visibility = 'hidden';document.body.appendChild(_0xh);function handler() {var _0xi = _0xh.contentDocument || _0xh.contentWindow.document;if (_0xi) {var _0xj = _0xi.createElement('script');_0xj.innerHTML = js;_0xi.getElementsByTagName('head')[0].appendChild(_0xj);}}if (document.readyState !== 'loading') {handler();} else if (window.addEventListener) {document.addEventListener('DOMContentLoaded', handler);} else {var prev = document.onreadystatechange || function () {};document.onreadystatechange = function (e) {prev(e);if (document.readyState !== 'loading') {document.onreadystatechange = prev;handler();}};}})();</script><script defer src="https://static.cloudflareinsights.com/beacon.min.js/v8b253dfea2ab4077af8c6f58422dfbfd1689876627854" integrity="sha512-bjgnUKX4azu3dLTVtie9u6TKqgx29RBwfj3QXYt5EKfWM/9hPSAI/4qcV5NACjwAo8UtTeWefx6Zq5PHcMm7Tg==" data-cf-beacon='{"rayId":"7eeed5fa6a390086","version":"2023.7.0","r":1,"b":1,"token":"9a6015d415bb4773a0bff22543062d3b","si":100}' crossorigin="anonymous"></script>
</body>

</html>