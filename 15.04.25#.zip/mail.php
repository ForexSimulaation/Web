<?php 
  $dest = "hwstechsup@gmail.com"; 
  $fromaddy = "hwtest@forexautonomy.com"; 
  mail("<$dest>","Test from php mail","Test","From:<$fromaddy>","-f$fromaddy"); 
?> 