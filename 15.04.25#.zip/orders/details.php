<?php

require_once("/home/mxjhxquy/public_html/office/linkto/membersite_config.php");

if(!$fgmembersite->CheckLogin())
{
    $fgmembersite->RedirectToURL("/office/login");
    exit;
}

   function username() //Return session_name
    {
require("/home/mxjhxquy/public_html/office/linkto/membersite_config.php");
$session_name=$fgmembersite->UserFullName();
return $session_name;
    }

   function useremail() //Return session_email
    {
require("/home/mxjhxquy/public_html/office/linkto/membersite_config.php");
$session_email=$fgmembersite->UserEmail();
return $session_email;
    }


   function userphone($email) //Retrieve session_phone SELECT * FROM `ForexAutonomyMembers`
    {
    {

$servernamef = 'DAL-Shared-26';
$usernamef = 'mxjhxquy_l';  
$passwordf = '141PRdS]p]';

$databasef = 'mxjhxquy_members';

$connectionf = new mysqli($servernamef,$usernamef,$passwordf,$databasef);

$queryf = "SELECT phonenumber FROM ForexAutonomyMembers WHERE email='$email'";

$resultf = $connectionf->query($queryf);

if ($resultf->num_rows > 0) {
  // output data of each row
  while($row = $resultf->fetch_assoc())
  {
  $phone= $row["phonenumber"];
  }
  }
  $connectionf -> close();
}
   return  $phone;
    }

    
$servername = 'DAL-Shared-26';
$username = 'mxjhxquy_l';  
$password = '141PRdS]p]';
$database = 'mxjhxquy_order';
$tablename = 'tradingsync';

$user_name = username();
$user_email = useremail();
$user_phone = userphone($user_email);


$connection = new mysqli($servername,$username,$password,$database);
/*
	$id = mysqli_real_escape_string($connection,$_POST['id']);
	$login = mysqli_real_escape_string($connection,$_POST['brokerlogin']);
	$password = mysqli_real_escape_string($connection,$_POST['traderpassword']);
	$server = mysqli_real_escape_string($connection,$_POST['brokerserver']);
	$engagement = mysqli_real_escape_string($connection,$_POST['equitypercentage']);

if (isset($_POST['submit']) && $login != '' ) 
{
$sql = "INSERT IGNORE INTO $tablename (login,password,server,engagement) VALUES ('$login','$password','$server','$engagement')"; 
}
*/
	$username = mysqli_real_escape_string($user_name);
	$useremail = mysqli_real_escape_string($user_email);
	$userphone = mysqli_real_escape_string($user_phone);
	$login = mysqli_real_escape_string($connection,$_POST['brokerlogin']);
	$password = mysqli_real_escape_string($connection,$_POST['traderpassword']);
	$server = mysqli_real_escape_string($connection,$_POST['brokerserver']);
	$engagement = mysqli_real_escape_string($connection,$_POST['equitypercentage']);

if (isset($_POST['submit']) && $login != '' ) 
{
$sql = "INSERT IGNORE INTO $tablename (session_name,session_email,session_phone,login,password,server,engagement) VALUES ('$user_name','$user_email','$user_phone','$login','$password','$server','$engagement')"; 
}

if ($connection -> query($sql)) {
//$country="";
}


$connection -> close();
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,minimum-scale=1">
<title>Trading Account Details Submission
</title>
   <link rel="STYLESHEET" type="text/css" href="style.css" />
   <link rel="icon" type="image/png" href="https://codeshack.io/projects/shoppingcart/advanced/favicon.png">
<link href="https://codeshack.io/projects/shoppingcart/advanced/style.css?v=1.1.0" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">

<header>
<div class="content-wrapper">
<h1>Trading Account Details Submission Form</h1>

<nav>
<a href="#" onclick="goBack()"><b>Previous Page</b></a>

<!--<nav>
<nav>
<a href="https://forexautonomy.com"><b>For More than One Account, Click Here</b></a>

<a href="https://forexautonomy.com"><b>Go To ForexAutonomy Home</b></a>

<a href="index?page=products"><b>Products Page</b></a>
</nav>
-->
</div>
</header>
<main>
<div class="checkout content-wrapper">
<div class="product content-wrapper">
    <img src="images/ACDs.jpg" width="500" height="300" alt="MetaTrader Account Details Submission Example">
    <div>
<form action="<?= $_SERVER['REQUEST_URI'] ?>" method="post">
<div class="row1">
<label for="brokerlogin"><b>Login</b></label>
<input type="text" value="" name="brokerlogin" id="brokerlogin" placeholder="00122345" required>
</div>
<div class="row2">
<label for="traderpassword"><b>Password</b></label>
<input type="password" value="" name="traderpassword" id="traderpassword" placeholder="Trader's Password" required>
</div>
<label for="brokerserver"><b>Server</b></label>
<input type="text" value="" name="brokerserver" id="brokerserver" placeholder="Exact Server Name of Broker" required>
<!-- <p>______________________________________________________________________________________</p> -->
<label for="equitypercentage"><i><b>Percentage Engagement (10% to 100%, default value 100%)</b></i></label>
<input type="range" value="100" step ="10" id="equitypercentage" name="equitypercentage" min="0" max="100" required>
<br>
<br>
<div class="stripe">
<button type="submit" name="submit">Submit</button>
</div>
</form>
</main>
<footer>
<div class="content-wrapper">
<p>&copy; 2021, Forex Autonomy Digital Products</p>
</div>
</footer>
<script>let currency_code="&dollar;";let base_url="https://codeshack.io/projects/shoppingcart/advanced/";let rewrite_url=true;</script>
<script src="https://codeshack.io/projects/shoppingcart/advanced/script.js?v=1.1.0"></script>
<script>
function goBack() {
  window.history.back();
}
</script>
</body>
</html>