<?php
include("/home/tecvidjt/public_html/var.php");
require_once("/home/tecvidjt/public_html/linkto/membersite_config.php");
$GSession = $_SESSION['googlesignin'];
$idSession = $_SESSION['googleid'];
$CheckLogin = $fgmembersite->CheckLogin();

if(!$CheckLogin && !$GSession) {$fgmembersite->RedirectToURL("/signin"); exit;}
include 'functions.php';
$pdo = pdo_connect_mysql();

//Basic Routing

// Page is set to home (default.php) by default, so when the visitor visits that will be the page they see.
$page = isset($_GET['page']) && file_exists($_GET['page'] . '.php') ? $_GET['page'] : 'products';
// Include and show the requested page
include $page . '.php';
?>