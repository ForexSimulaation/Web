<?php

function pdo_connect_mysql() {
    // Update the details below with your MySQL details
    $DATABASE_HOST = 'dal-shared-30';
    $DATABASE_USER = 'tecvidjt_l';
    $DATABASE_PASS = '141PRdS]p]';
    $DATABASE_NAME = 'tecvidjt_order';

    try {
    	return new PDO('mysql:host=' . $DATABASE_HOST . ';dbname=' . $DATABASE_NAME . ';charset=utf8', $DATABASE_USER, $DATABASE_PASS);
    } catch (PDOException $exception) {
    	// If there is an error with the connection, stop the script and display the error.
    	exit('Failed to connect to database!');
    }

//Variable Declaration
// Get the amount of items in the shopping cart, this will be displayed in the header.
}

// Template header, feel free to customize this
function template_header($title)

{$num_items_in_cart = isset($_SESSION['cart']) ? count($_SESSION['cart']) : 0;

$url.= $_SERVER['REQUEST_URI'];    
//    echo $url; 
 if ($url =="/order/index?page=orderplaced")
 {
//$_SESSION['cart'] = 0;
$num_items_in_cart = 0;
//echo "hope";

/*if (isset($_POST['orders'])&& !empty($_SESSION['cart']))
{
$_SESSION['cart'] = 0;
$num_items_in_cart = 0;
}*/
}


// Template header, feel free to customize this
function detailsredirect()

{$url.= $_SERVER['REQUEST_URI'];    
//    echo $url; 
 if (($url =="/orders/index?page=product&id=6")||($url =="/orders/index?page=product&id=7"))
 {echo '<p class="error"></p>
<p>Submit your <b>Trading Account Details </b> <a href="details"> Here</a></p>';}

}


// Template header, feel free to customize this
function productquantity()

{$url.= $_SERVER['REQUEST_URI'];    
//    echo $url; 
 if ($url =="/orders/index?page=product&id=6"||$url =="/orders/index?page=product&id=7")

 {echo '<input type="number" name="quantity" min="1" max="1000" placeholder="Number of Months for Subscription" required>';}
            else
 {echo '<input type="number" name="quantity" min="1" max="1000" placeholder="Quantity of Unique Licensed Copies" required>';}

/*
 {echo '<input type="number" name="quantity" min="1" max="1000" placeholder="Number of Months for Subscription" required>
            <input type="number" name="time" min="1" max="100" placeholder="Number of Unique Trading Accounts " required>';}
            else
 {echo '<input type="number" name="quantity" min="1" max="1000" placeholder="Quantity of Unique Licensed Copies" required>';}
*/


}



echo <<<EOT
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>$title</title>
		<link href="style.css" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
	</head>
	<body>
        <header>
            <div class="content-wrapper">
                <h1>Forex Autonomy Product Cart</h1>
                <nav>
                    <a href="index?page=products&p=1"><b>Choose Your Product</b></a>
                </nav>
                <div class="link-icons">
                    <a href="index?page=cart">
						<i class="fas fa-shopping-cart"></i><span>$num_items_in_cart</span>


					</a>
                </div>
            </div>
        </header>
        <main>
EOT;
}

// Template footer
function template_footer() {
$year = date('Y');
echo <<<EOT
        </main>
        <footer>
            <div class="content-wrapper">
                <p>&copy; $year, Forex Autonomy Digital Products</p>
            </div>
        </footer>
        <script src="script.js"></script>
    </body>
</html>
EOT;
}
?>