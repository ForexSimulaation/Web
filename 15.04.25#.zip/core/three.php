<?PHP

$rawdata = file_get_contents('php://input');

$servername = 'dal-shared-30';
$username = 'tecvidjt_ex';  
$password = '!sUs]ecoqO0W';
$database = 'tecvidjt_pluto';
$tablename = 'GTDTrois';
//---
$connection = new mysqli($servername,$username,$password,$database);
$key=strlen($rawdata);

if ($key>4) {$sql="INSERT INTO $tablename (gridthree) VALUES ('$rawdata')";}
//---
$connection -> query($sql);
{if ($key<4) header("Location: /live.php"); }
$connection -> close();


//---
$rdeal= new mysqli($servername, $username, $password, $database);
$query = "select gridthree from $tablename order by id_user desc limit 1;";
$queryResult = $rdeal->query($query);
while ($queryRow = $queryResult->fetch_row()) {
 $I0 = $queryRow[0];
}$rdeal->close();

{if ($key==4) echo $I0; }
?>

