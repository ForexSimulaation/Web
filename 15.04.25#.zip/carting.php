<?php
require_once("/home/tecvidjt/public_html/linkto/membersite_config.php");
    // Retrieve and transfer Session Variables
$nameSession = $_SESSION['google_name'];
$emailSession = $_SESSION['google_email'];
$GSession = $_SESSION['googlesignin'];
$idSession = $_SESSION['googleid'];
$CheckLogin = $fgmembersite->CheckLogin();

$data = var_dump($_SESSION);

if(!$CheckLogin && !$GSession) {$fgmembersite->RedirectToURL("/signin"); exit;}



?>


